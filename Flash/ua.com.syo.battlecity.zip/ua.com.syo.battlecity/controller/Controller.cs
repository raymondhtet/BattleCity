﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.controller
{
    public class Controller : Flash.var
    {
        private static Controller instance = null;

        public Controller()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public Controller getInstance()
        {
            if (ua.com.syo.battlecity.controller.Controller.instance == null)
            {
                ua.com.syo.battlecity.controller.Controller.instance = new ua.com.syo.battlecity.controller.Controller();
            } // end if
            return (ua.com.syo.battlecity.controller.Controller.instance);
        }

        public void init()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().addListener(this);
            //ua.com.syo.battlecity.model.Model.getInstance().addListener(this);
        }

        public void run()
        {
            //ua.com.syo.battlecity.data.GlobalStorage.initDynamicVars();
            //ua.com.syo.battlecity.view.UIManager.getInstance().showSplashMenu();
        }

        public void onCloseSplashMenu()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().showSelectStage(ua.com.syo.battlecity.data.GlobalStorage.currentStage);
        }

        public void onSelectStage(Flash.var stage)
        {
            //ua.com.syo.battlecity.model.Model.getInstance().getMap(stage);
            //ua.com.syo.battlecity.data.GlobalStorage.currentStage = stage;
        }

        public void onStageLoad()
        {
            //ua.com.syo.battlecity.controller.GameController.getInstance().init();
        }

        public void onCloseTotalScreen(Flash.var isGO)
        {
            //if (isGO)
            //{
            //    ua.com.syo.battlecity.view.UIManager.getInstance().showGameOverScreen();
            //}
            //else
            //{
            //    ++ua.com.syo.battlecity.data.GlobalStorage.currentStage;
            //    if (ua.com.syo.battlecity.data.GlobalStorage.currentStage > ua.com.syo.battlecity.data.GlobalStorage.stagesNum)
            //    {
            //        ua.com.syo.battlecity.data.GlobalStorage.currentStage = 1;
            //    } // end if
            //    ua.com.syo.battlecity.view.UIManager.getInstance().showSelectStage(ua.com.syo.battlecity.data.GlobalStorage.currentStage);
            //} // end else if
        }

        public void onTheEnd()
        {
            this.run();
        }
    }
}
