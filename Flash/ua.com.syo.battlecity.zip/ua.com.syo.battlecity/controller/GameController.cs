﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.controller
{
    public class GameController : Flash.Clip
    {
        private static GameController instance = null;

        public GameController()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public GameController getInstance()
        {
            if (ua.com.syo.battlecity.controller.GameController.instance == null)
            {
                ua.com.syo.battlecity.controller.GameController.instance = new ua.com.syo.battlecity.controller.GameController();
            } // end if
            return (ua.com.syo.battlecity.controller.GameController.instance);
        }

        public void init()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().addListener(this);
            this.showStage();
            this.showTank();
        }

        public void showStage()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().showStage();
        }

        public void showTank()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showTank();
            //this.tanksMoveEnable();
            //this.bombsMoveEnable();
            //this.showEnemyEnable();
        }

        public void tanksMoveEnable()
        {
            //if (this.tanksMoveIntervalId != null)
            //{
            //    _global.clearInterval(this.tanksMoveIntervalId);
            //} // end if
            //this.tanksMoveIntervalId = _global.setInterval(this, "moveAllTanks", ua.com.syo.battlecity.data.GlobalStorage.tanksMoveInterval);
        }

        public void bombsMoveEnable()
        {
            //if (this.bombsMoveIntervalId != null)
            //{
            //    _global.clearInterval(this.bombsMoveIntervalId);
            //} // end if
            //this.bombsMoveIntervalId = _global.setInterval(this, "moveAllBombs", ua.com.syo.battlecity.data.GlobalStorage.bombsMoveInterval);
        }

        public void showEnemyEnable()
        {
            //if (this.showEnemyIntervalId != null)
            //{
            //    _global.clearInterval(this.showEnemyIntervalId);
            //} // end if
            //this.showEnemyIntervalId = _global.setInterval(this, "showNextEnemy", ua.com.syo.battlecity.data.GlobalStorage.showEnemyInterval);
        }

        public void moveAllTanks()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().moveAllTanks();
        }

        public void moveAllBombs()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().moveAllBombs();
        }

        public void showNextEnemy()
        {
            //if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyLeft() > 0 && ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage < ua.com.syo.battlecity.data.GlobalStorage.maxEnemyOnStage)
            //    {
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showNextEnemy();
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().infoPanelUpdate();
            //        trace("ON STAGE: " + ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage);
            //    } // end if
            //} // end if
        }

        public void putPlayerBomb()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().putPlayerBomb(x, y, direction, speed, isFerumErase);
        }

        public void putEnemyBomb()
        {
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().putEnemyBomb(x, y, direction, speed);
        }

        public void putBonus()
        {
        }
    }
}
