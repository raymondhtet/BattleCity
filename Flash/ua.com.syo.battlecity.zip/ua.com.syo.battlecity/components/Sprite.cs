﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.components
{
    public class Sprite : Flash.Clip
    {
        private Flash.var type = null;
        private Flash.Clip sprite_mc = null;

        public Sprite()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public static Sprite create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            Flash.Object.registerClass("__Packages.ua.com.syo.battlecity.components.Sprite", typeof(ua.com.syo.battlecity.components.Sprite));
            Flash.var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.components.Sprite", name, depth, initObject);
            Sprite _loc7 = (ua.com.syo.battlecity.components.Sprite)(_loc6);
            _loc7.buildInstance();
            return (_loc7);
        }

        public void buildInstance()
        {
        }

        public void init(Flash.var x, Flash.var y, Flash.var type)
        {
            this.type = type;
            this.sprite_mc = this.attachMovie(type, type, 1);
            this._x = x;
            this._y = y;
        }

        public void destroy()
        {
            this.removeMovieClip(this);
        }

        public Flash.var nextErase(Flash.var direction)
        {
            Flash.var _loc3 = false;
            Flash.var _loc4 = 1;
            if (this.type == "brick")
            {
            } // end if
            if (this.type == "brick")
            {
                Flash.var _loc5 = this.sprite_mc._currentframe;
                if (_loc5 > 5)
                {
                    _loc3 = true;

                }
                else
                {
                    switch ((int)direction)
                    {
                        case 1:
                            {
                                if (_loc5 == 2 || _loc5 == 3)
                                {
                                    _loc3 = true;
                                    break;
                                }
                                else if (_loc5 == 1)
                                {
                                    this.sprite_mc.gotoAndStop(2);
                                    break;
                                }
                                else if (_loc5 == 4)
                                {
                                    this.sprite_mc.gotoAndStop(7);
                                    break;
                                }
                                else if (_loc5 == 5)
                                {
                                    this.sprite_mc.gotoAndStop(6);
                                    break;
                                } // end else if
                                break;
                            }
                        case 2:
                            {
                                if (_loc5 == 2 || _loc5 == 3)
                                {
                                    _loc3 = true;
                                    break;
                                }
                                else if (_loc5 == 1)
                                {
                                    this.sprite_mc.gotoAndStop(3);
                                    break;
                                }
                                else if (_loc5 == 4)
                                {
                                    this.sprite_mc.gotoAndStop(9);
                                    break;
                                }
                                else if (_loc5 == 5)
                                {
                                    this.sprite_mc.gotoAndStop(8);
                                    break;
                                } // end else if
                                break;
                            }
                        case 3:
                            {
                                if (_loc5 == 4 || _loc5 == 5)
                                {
                                    _loc3 = true;
                                    break;
                                }
                                else if (_loc5 == 1)
                                {
                                    this.sprite_mc.gotoAndStop(4);
                                    break;
                                }
                                else if (_loc5 == 2)
                                {
                                    this.sprite_mc.gotoAndStop(7);
                                    break;
                                }
                                else if (_loc5 == 3)
                                {
                                    this.sprite_mc.gotoAndStop(9);
                                    break;
                                } // end else if
                                break;
                            }
                        case 4:
                            {
                                if (_loc5 == 4 || _loc5 == 5)
                                {
                                    _loc3 = true;
                                    break;
                                }
                                else if (_loc5 == 1)
                                {
                                    this.sprite_mc.gotoAndStop(5);
                                    break;
                                }
                                else if (_loc5 == 2)
                                {
                                    this.sprite_mc.gotoAndStop(6);
                                    break;
                                }
                                else if (_loc5 == 3)
                                {
                                    this.sprite_mc.gotoAndStop(8);
                                    break;
                                } // end else if
                                break;
                            }
                    } // End of switch
                } // end if
            } // end else if
            return _loc3;
        }
    }
}
