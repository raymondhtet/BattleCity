﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.components
{
    public class NESNumField : Flash.Clip
    {
        private Flash.Clip canvas_mc = null;
        private Flash.var maxChar = null;
        private Flash.var align = null;
        private Flash.var value = null;

        public NESNumField()
        {
            // ASSetPropFlags(_loc1, null, 1);
            this.align = "left";
        }

        public static NESNumField create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            Flash.Object.registerClass("__Packages.ua.com.syo.battlecity.components.NESNumField", typeof(ua.com.syo.battlecity.components.NESNumField));
            Flash.var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.components.NESNumField", name, depth, initObject);
            NESNumField _loc7 = (ua.com.syo.battlecity.components.NESNumField)(_loc6);
            _loc7.buildInstance();

            return _loc7;
        }

        public void buildInstance()
        {
            this.canvas_mc = this.createEmptyMovieClip("canvas_mc", this.getNextHighestDepth());
        }

        public void init(Flash.var x, Flash.var y, Flash.var maxChar, Flash.var align, Flash.Color color)
        {
            this.maxChar = maxChar;
            this.align = align;
            Flash.var _loc7 = 0;
            
            while (_loc7 < this.maxChar)
            {
                ++_loc7;
                //this.canvas_mc.attachMovie("numeric", "num_" + _loc7, this.canvas_mc.getNextHighestDepth(), {_x: _loc7 * 8 + x, _y: y});
                Flash.Color _loc8 = new Flash.Color(this.canvas_mc["num_" + _loc7.ToString()]);
                _loc8.setRGB(color);
            } // end while
        }

        public void setValue(Flash.var value)
        {
            this.value = Flash.Number(value);
            Flash.var _loc4 = this.maxChar - value.length;
            Flash.var _loc5 = 0;
            Flash.Clip _loc3 = null;

            while (_loc5 < this.maxChar)
            {
                ++_loc5;
                _loc3 = (Flash.Clip)this.canvas_mc["num_" + _loc5.ToString()];
                _loc3.gotoAndStop("n");
            } // end while
            Flash.var _loc6 = 0;
            
            while (_loc6 < value.length)
            {
                ++_loc6;

                Flash.var _loc7 = value.slice(_loc6, _loc6 + 1);
                if (this.align == "right")
                {
                    _loc3 = (Flash.Clip)this.canvas_mc["num_" + (_loc4 + _loc6).ToString()];
                }
                else
                {
                    _loc3 = (Flash.Clip)this.canvas_mc["num_" + _loc6.ToString()];
                } // end else if
                _loc3.gotoAndStop("n" + _loc7.ToString());
            } // end while
        }

        public Flash.var getValue()
        {
            return this.value;
        }
    }
}
