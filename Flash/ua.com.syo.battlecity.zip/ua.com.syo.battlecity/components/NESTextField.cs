﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.components
{
    public class NESTextField : Flash.Clip
    {
        public Flash.Clip canvas_mc = null;

        public NESTextField()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public static NESTextField create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            Flash.Object.registerClass("__Packages.ua.com.syo.battlecity.components.NESTextField", typeof(ua.com.syo.battlecity.components.NESTextField));
            Flash.var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.components.NESTextField", name, depth, initObject);
            NESTextField _loc7 = (ua.com.syo.battlecity.components.NESTextField)(_loc6);
            _loc7.buildInstance();

            return _loc7;
        }

        public void buildInstance()
        {
            this.canvas_mc = this.createEmptyMovieClip("canvas_mc", this.getNextHighestDepth());
            this.canvas_mc._visible = false;
        }

        public void init(Flash.var x, Flash.var y, Flash.var text, Flash.Color color)
        {
            this.canvas_mc._visible = true;
            var _loc6 = 0;
            
            while (_loc6 < text.length)
            {
                ++_loc6;
                Flash.var _loc7 = text.slice(_loc6, _loc6 + 1);
                if (_loc7 != " ")
                {
                    //this.canvas_mc.attachMovie(text.slice(_loc6, _loc6 + 1), "char_" + _loc6, this.canvas_mc.getNextHighestDepth(), {_x: _loc6 * 8 + x, _y: y});
                    Flash.Color _loc8 = new Flash.Color(this.canvas_mc["char_" + _loc6]);
                    _loc8.setRGB(color);
                } // end if
            } // end while
        }
    }
}
