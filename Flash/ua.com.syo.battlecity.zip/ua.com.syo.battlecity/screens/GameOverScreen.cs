﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens
{
    public class GameOverScreen : Flash.Clip
    {
        public GameOverScreen()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.GameOverScreen", ua.com.syo.battlecity.screens.GameOverScreen);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.GameOverScreen", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.GameOverScreen)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.attachMovie("rectangle", "rectangle", this.getNextHighestDepth());
            //this.bricks_mc = this.createEmptyMovieClip("bricks", this.getNextHighestDepth());
            //this.canvas_mc = this.createEmptyMovieClip("canvas", this.getNextHighestDepth());
            //this.goText1 = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "goText1", this.canvas_mc.getNextHighestDepth());
            //this.goText2 = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "goText2", this.canvas_mc.getNextHighestDepth());
        }

        public void init()
        {
            //AsBroadcaster.initialize(this);
            //var _loc2 = 8;
            
            //while (++_loc2, _loc2 < 24)
            //{
            //    var _loc3 = 8;
                
            //    while (++_loc3, _loc3 < 19)
            //    {
            //        this.bricks_mc.attachMovie("brick", "b" + _loc2 * 100 + _loc3, this.bricks_mc.getNextHighestDepth(), {_x: _loc2 * 8, _y: _loc3 * 8});
            //    } // end while
            //} // end while
            //this.goText1.init(0, 0, "game", 14166016);
            //this.goText2.init(0, 0, "over", 14166016);
            //this.goText1._xscale = this.goText1._yscale = this.goText2._xscale = this.goText2._yscale = 400;
            //this.goText1._x = 64;
            //this.goText1._y = 64;
            //this.goText2._x = 64;
            //this.goText2._y = 116;
            //this.bricks_mc.setMask(this.canvas_mc);
            //this.runDelay();
        }

        public void runDelay()
        {
            //var delay = 100;
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    --delay;
            //    if (delay < 0)
            //    {
            //        $scope.close();
            //    } // end if
            //};
        }

        public void close()
        {
            this.broadcastMessage("onCloseGameOverScreen");
        }

        public void destroy()
        {
            this.removeMovieClip();
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
