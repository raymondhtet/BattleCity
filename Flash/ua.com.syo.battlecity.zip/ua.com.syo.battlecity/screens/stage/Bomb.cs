﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class Bomb : Flash.Clip
    {
        public Bomb()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //this.direction_array = new Array("up", "down", "left", "right");
            //this.isMove = true;
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.Bomb", ua.com.syo.battlecity.screens.stage.Bomb);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.Bomb", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.Bomb)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.bomb = this.attachMovie("bomb", "bomb", this.getNextHighestDepth());
        }

        public void init(Flash.var x, Flash.var y, Flash.var direction, Flash.var speed, Flash.var isPlayerBomb, Flash.var isEraseFerum)
        {
            //this.bomb._x = this.x = x;
            //this.bomb._y = this.y = y;
            //this.direction = direction;
            //this.speed = speed;
            //this.isPlayerBomb = isPlayerBomb;
            //this.isEraseFerum = isEraseFerum;
            //this.correctBombPosition();
            //switch (this.direction)
            //{
            //    case 1:
            //        {
            //            this.dx = 0;
            //            this.dy = -1;
            //            break;
            //        }
            //    case 2:
            //        {
            //            this.dx = 0;
            //            this.dy = 1;
            //            break;
            //        }
            //    case 3:
            //        {
            //            this.dx = -1;
            //            this.dy = 0;
            //            break;
            //        }
            //    case 4:
            //        {
            //            this.dx = 1;
            //            this.dy = 0;
            //            break;
            //        }
            //} // End of switch
            //this.bomb.gotoAndStop(this.direction_array[this.direction - 1]);
        }

        public void move()
        {
            //if (this.isMove)
            //{
            //    var _loc4 = this.x;
            //    var _loc5 = this.y;
            //    var _loc6 = Math.round(_loc4 / 8);
            //    var _loc7 = Math.round(_loc5 / 8);
            //    var _loc2 = _loc6;
            //    var _loc3 = _loc7;
            //    if (!this.isPlayerBomb)
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.clearBombMap(_loc2, _loc3);
            //    } // end if
            //    var _loc8 = this.x + this.dx * this.speed;
            //    var _loc9 = this.y + this.dy * this.speed;
            //    switch (this.direction)
            //    {
            //        case 1:
            //            {
            //                _loc2 = _loc8 / 8;
            //                _loc3 = Math.round(_loc9 / 8);
            //                break;
            //            }
            //        case 2:
            //            {
            //                _loc2 = _loc8 / 8;
            //                _loc3 = Math.ceil((_loc9 + 6) / 8);
            //                break;
            //            }
            //        case 3:
            //            {
            //                _loc2 = Math.round(_loc8 / 8);
            //                _loc3 = _loc9 / 8;
            //                break;
            //            }
            //        case 4:
            //            {
            //                _loc2 = Math.ceil((_loc8 + 6) / 8);
            //                _loc3 = _loc9 / 8;
            //                break;
            //            }
            //    } // End of switch
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForBomb(_loc2, _loc3, this.direction))
            //    {
            //        this.bomb._x = this.x = _loc8;
            //        this.bomb._y = this.y = _loc9;
            //        this.correctBombPosition();
            //        if (!this.isPlayerBomb)
            //        {
            //            var _loc10 = Math.round(this.x / 8);
            //            var _loc11 = Math.round(this.y / 8);
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.fillBombMap(_loc10, _loc11, this);
            //        } // end if
            //    }
            //    else
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.eraseBrick(_loc2, _loc3, this.direction, this.isEraseFerum);
            //        this.destroy();
            //    } // end else if
            //    if (this.isPlayerBomb)
            //    {
            //        if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.checkEnemyForBomb(_loc2, _loc3, this.direction))
            //        {
            //            this.destroy();
            //        } // end if
            //    }
            //    else if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.checkPlayerForBomb(_loc2, _loc3, this.direction, this))
            //    {
            //        this.destroy();
            //    } // end if
            //} // end else if
        }

        public void correctBombPosition()
        {
            //switch (this.direction)
            //{
            //    case 1:
            //        {
            //            this.bomb._x = this.bomb._x + 4;
            //            this.bomb._y = this.bomb._y - 1;
            //            break;
            //        }
            //    case 2:
            //        {
            //            this.bomb._x = this.bomb._x + 3;
            //            this.bomb._y = this.bomb._y + 11;
            //            break;
            //        }
            //    case 3:
            //        {
            //            this.bomb._x = this.bomb._x - 1;
            //            this.bomb._y = this.bomb._y + 5;
            //            break;
            //        }
            //    case 4:
            //        {
            //            this.bomb._x = this.bomb._x + 10;
            //            this.bomb._y = this.bomb._y + 5;
            //            break;
            //        }
            //} // End of switch
        }

        public void destroy()
        {
            //this.isMove = false;
            //if (this.isPlayerBomb)
            //{
            //    --ua.com.syo.battlecity.screens.stage.CurrentStageData.currentPlayerBombNum;
            //}
            //else
            //{
            //    var _loc3 = Math.round(this.x / 8);
            //    var _loc4 = Math.round(this.y / 8);
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.clearBombMap(_loc3, _loc4);
            //} // end else if
            //if (!isAnigilation)
            //{
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showBlast(this.bomb._x, this.bomb._y, "explosive");
            //} // end if
            //this.removeMovieClip();
        }
    }
}
