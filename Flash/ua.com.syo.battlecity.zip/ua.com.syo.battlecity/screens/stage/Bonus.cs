﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class Bonus : Flash.Clip
    {
        public Bonus()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //this.blinkingDelay = 0;
            //this.bonusId_array = new Array("star", "grenade", "lifeAdd", "helmet", "clock", "spade");
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.Bonus", ua.com.syo.battlecity.screens.stage.Bonus);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.Bonus", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.Bonus)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
        }

        public void init(Flash.var x, Flash.var y, Flash.var type)
        {
            //this.x = x;
            //this.y = y;
            //this.type = type;
            //this.bonus_mc = this.attachMovie(this.bonusId_array[type], "bonus", this.getNextHighestDepth());
            //this.bonus_mc._x = x * 8;
            //this.bonus_mc._y = y * 8;
            //this.startBlink();
        }

        public void startBlink()
        {
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    --$scope.blinkingDelay;
            //    if ($scope.blinkingDelay < 0)
            //    {
            //        $scope.bonus_mc._visible = false;
            //    }
            //    else
            //    {
            //        $scope.bonus_mc._visible = true;
            //    } // end else if
            //    if ($scope.blinkingDelay < -7)
            //    {
            //        $scope.blinkingDelay = 14;
            //    } // end if
            //};
        }

        public void getType()
        {
            //return (this.type);
        }

        public void getX()
        {
            //return (this.x);
        }

        public void getY()
        {
            //return (this.y);
        }

        public void destroy()
        {
            this.removeMovieClip();
        }
    }
}
