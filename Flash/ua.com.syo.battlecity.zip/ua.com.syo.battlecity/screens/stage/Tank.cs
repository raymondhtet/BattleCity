﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class Tank : Flash.Clip
    {
        public Tank()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //_loc1.direction = 1;
            //_loc1.direction_array = new Array("up", "down", "left", "right");
            //_loc1.tankType_array = new Array("tank0", "tank1", "tank2", "tank3");
            //_loc1.bombSpeed_array = new Array(2, 3, 3, 3);
            //_loc1.bombLimit_array = new Array(1, 1, 2, 2);
            //_loc1.ferumErase_array = new Array(false, false, false, true);
            //_loc1.isMove = false;
            //_loc1.isPortalView = true;
            //_loc1.isArmor = true;
            //_loc1.isDestroy = false;
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.Tank", ua.com.syo.battlecity.screens.stage.Tank);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.Tank", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.Tank)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
        }

        public void init(Flash.var tankType)
        {
            //this.keyStack_array = new Array();
            //this.isMove = false;
            //this.isPortalView = true;
            //this.iceDelay = 0;
            //this.direction = 1;
            //if (!tankType)
            //{
            //    this.currentTankType = 0;
            //}
            //else
            //{
            //    this.currentTankType = tankType;
            //} // end else if
            //var _loc3 = Math.round(64 / 8);
            //var _loc4 = Math.round(192 / 8);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc3, _loc4, this);
            //this.putOnStartPosition();
        }

        public void putOnStartPosition()
        {
            //this.showPortal();
        }

        public void showPortal()
        {
            //this.portal = this.attachMovie("portalTank", "portal", this.getNextHighestDepth(), {_x: 64, _y: 192});
            //this.portal.scope = this;
            //this.portal.gotoAndPlay(1);
        }

        public void onPortalHide()
        {
            //this.showTank();
            //this.isPortalView = false;
            //this.portal.removeMovieClip();
        }

        public void showTank()
        {
            //this.currentTank = this.attachMovie(this.tankType_array[this.currentTankType], "tank", 1);
            //this.armor = this.currentTank.attachMovie("armor", "armor", this.getNextHighestDepth());
            //this.isArmor = true;
            //this.armorDelay = Math.round(ua.com.syo.battlecity.data.GlobalStorage.armorDelay / 5);
            //this.currentTank._x = 64;
            //this.currentTank._y = 192;
            //this.enableControl();
            //this.arrangeTank();
            //this.isMove = true;
        }

        public void enableControl()
        {
            //Key.addListener(this);
            //this.isMove = true;
        }

        public void disableControl()
        {
            //this.keyStack_array = new Array();
            //Key.removeListener(this);
            //this.isMove = false;
        }

        public void onKeyDown()
        {
            //if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    if (Key.getCode() == 32)
            //    {
            //        if (ua.com.syo.battlecity.screens.stage.CurrentStageData.currentPlayerBombNum < this.bombLimit_array[this.currentTankType])
            //        {
            //            ua.com.syo.battlecity.controller.GameController.getInstance().putPlayerBomb(this.currentTank._x, this.currentTank._y, this.direction, this.bombSpeed_array[this.currentTankType], this.ferumErase_array[this.currentTankType]);
            //            ++ua.com.syo.battlecity.screens.stage.CurrentStageData.currentPlayerBombNum;
            //        } // end if
            //    }
            //    else
            //    {
            //        if (Key.getCode() == 38)
            //        {
            //            this.dx = 0;
            //            this.dy = -1;
            //            this.direction = 1;
            //            if (this.keyStack_array[0] != this.direction)
            //            {
            //                this.keyStack_array.unshift(this.direction);
            //            } // end if
            //            this.arrangeTank();
            //        } // end if
            //        if (Key.getCode() == 40)
            //        {
            //            this.dx = 0;
            //            this.dy = 1;
            //            this.direction = 2;
            //            if (this.keyStack_array[0] != this.direction)
            //            {
            //                this.keyStack_array.unshift(this.direction);
            //            } // end if
            //            this.arrangeTank();
            //        } // end if
            //        if (Key.getCode() == 37)
            //        {
            //            this.dx = -1;
            //            this.dy = 0;
            //            this.direction = 3;
            //            if (this.keyStack_array[0] != this.direction)
            //            {
            //                this.keyStack_array.unshift(this.direction);
            //            } // end if
            //            this.arrangeTank();
            //        } // end if
            //        if (Key.getCode() == 39)
            //        {
            //            this.dx = 1;
            //            this.dy = 0;
            //            this.direction = 4;
            //            if (this.keyStack_array[0] != this.direction)
            //            {
            //                this.keyStack_array.unshift(this.direction);
            //            } // end if
            //            this.arrangeTank();
            //        } // end if
            //    } // end if
            //} // end else if
        }

        public void onKeyUp()
        {
            //if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    if (Key.getCode() == 38)
            //    {
            //        this.shiftArray(1);
            //    } // end if
            //    if (Key.getCode() == 40)
            //    {
            //        this.shiftArray(2);
            //    } // end if
            //    if (Key.getCode() == 37)
            //    {
            //        this.shiftArray(3);
            //    } // end if
            //    if (Key.getCode() == 39)
            //    {
            //        this.shiftArray(4);
            //    } // end if
            //    switch (this.keyStack_array[0])
            //    {
            //        case 1:
            //            {
            //                this.dx = 0;
            //                this.dy = -1;
            //                this.direction = 1;
            //                break;
            //            }
            //        case 2:
            //            {
            //                this.dx = 0;
            //                this.dy = 1;
            //                this.direction = 2;
            //                break;
            //            }
            //        case 3:
            //            {
            //                this.dx = -1;
            //                this.dy = 0;
            //                this.direction = 3;
            //                break;
            //            }
            //        case 4:
            //            {
            //                this.dx = 1;
            //                this.dy = 0;
            //                this.direction = 4;
            //                break;
            //            }
            //    } // End of switch
            //    this.arrangeTank();
            //} // end if
        }

        public void shiftArray(Flash.var direction)
        {
            //if (this.keyStack_array[1] == 0 || this.keyStack_array[0] == direction)
            //{
            //    this.direction = direction;
            //} // end if
            //var _loc3 = 0;
            
            //while (++_loc3, _loc3 < 4)
            //{
            //    if (this.keyStack_array[_loc3] == direction)
            //    {
            //        this.keyStack_array.splice(_loc3, 1);
            //    } // end if
            //} // end while
        }

        public void arrangeTank()
        {
            //this.currentTank.gotoAndStop(this.direction_array[this.direction - 1]);
            //if (this.direction == 1 || this.direction == 2)
            //{
            //    this.currentTank._x = Math.round(this.currentTank._x / 8) * 8;
            //}
            //else
            //{
            //    this.currentTank._y = Math.round(this.currentTank._y / 8) * 8;
            //} // end else if
            //if (this.keyStack_array.length == 0)
            //{
            //    this.olddx = this.dx;
            //    this.olddy = this.dy;
            //    this.dx = 0;
            //    this.dy = 0;
            //} // end if
        }

        public void move(Flash.var isStopped)
        {
            //if (this.isMove)
            //{
            //    if (this.dx || this.dy)
            //    {
            //        var _loc5 = Math.round(this.currentTank._x / 8);
            //        var _loc6 = Math.round(this.currentTank._y / 8);
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.clearTankMap(_loc5, _loc6);
            //        var _loc7 = this.currentTank._x + this.dx;
            //        var _loc8 = this.currentTank._y + this.dy;
            //        if (this.direction == 1 || this.direction == 3)
            //        {
            //            var _loc3 = Math.floor(_loc7 / 8);
            //            var _loc4 = Math.floor(_loc8 / 8);
            //        }
            //        else
            //        {
            //            _loc3 = Math.ceil(_loc7 / 8);
            //            _loc4 = Math.ceil(_loc8 / 8);
            //        } // end else if
            //        if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(_loc3, _loc4))
            //        {
            //            this.currentTank._x = _loc7;
            //            this.currentTank._y = _loc8;
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(Math.round(_loc7 / 8), Math.round(_loc8 / 8), this);
            //        }
            //        else
            //        {
            //            this.iceDelay = 0;
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc5, _loc6, this);
            //        } // end else if
            //        if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkIce(_loc3, _loc4))
            //        {
            //            this.iceDelay = ua.com.syo.battlecity.data.GlobalStorage.slidingDelay;
            //        } // end if
            //        var _loc9 = this.currentTank._currentframe / 2;
            //        if (_loc9 - Math.round(_loc9) == 0)
            //        {
            //            this.currentTank.prevFrame();
            //        }
            //        else
            //        {
            //            this.currentTank.nextFrame();
            //        } // end else if
            //    }
            //    else if (this.iceDelay > 0)
            //    {
            //        --this.iceDelay;
            //        var _loc12 = Math.round(this.currentTank._x / 8);
            //        var _loc13 = Math.round(this.currentTank._y / 8);
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.clearTankMap(_loc12, _loc13);
            //        var _loc14 = this.currentTank._x + this.olddx;
            //        var _loc15 = this.currentTank._y + this.olddy;
            //        if (this.direction == 1 || this.direction == 3)
            //        {
            //            var _loc10 = Math.floor(_loc14 / 8);
            //            var _loc11 = Math.floor(_loc15 / 8);
            //        }
            //        else
            //        {
            //            _loc10 = Math.ceil(_loc14 / 8);
            //            _loc11 = Math.ceil(_loc15 / 8);
            //        } // end else if
            //        if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(_loc10, _loc11))
            //        {
            //            this.currentTank._x = _loc14;
            //            this.currentTank._y = _loc15;
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(Math.round(_loc14 / 8), Math.round(_loc15 / 8), this);
            //        }
            //        else
            //        {
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc12, _loc13, this);
            //        } // end else if
            //        if (this.iceDelay > 11)
            //        {
            //            if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.checkIce(_loc10, _loc11))
            //            {
            //                this.iceDelay = 8;
            //            } // end if
            //        } // end if
            //    } // end else if
            //    if (this.armorDelay > 0)
            //    {
            //        --this.armorDelay;
            //    }
            //    else
            //    {
            //        this.isArmor = false;
            //        this.armor._visible = false;
            //    } // end else if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBonusCollision(this))
            //    {
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onCheckBonus();
            //    } // end if
            //} // end if
        }

        public void setOnPause()
        {
            //this.dx = 0;
            //this.dy = 0;
            //this.keyStack_array = new Array();
        }

        public void getType()
        {
            //return ("player");
        }

        public void getStatus()
        {
            //if (this.isPortalView)
            //{
            //    return ("portal");
            //}
            //else if (this.isArmor)
            //{
            //    return ("armor");
            //}
            //else
            //{
            //    return ("tank");
            //} // end else if
        }

        public void upRank()
        {
            //if (this.currentTankType < 3)
            //{
            //    ++this.currentTankType;
            //    var _loc2 = this.currentTank._x;
            //    var _loc3 = this.currentTank._y;
            //    this.currentTank.removeMovieClip();
            //    this.currentTank = this.attachMovie(this.tankType_array[this.currentTankType], "tank", 1);
            //    this.currentTank._x = _loc2;
            //    this.currentTank._y = _loc3;
            //    ua.com.syo.battlecity.data.GlobalStorage.currentTankType = this.currentTankType;
            //    this.arrangeTank();
            //} // end if
        }

        public void setArmor()
        {
            //this.armor._visible = true;
            //this.isArmor = true;
            //this.armorDelay = Math.round(ua.com.syo.battlecity.data.GlobalStorage.armorDelay);
        }

        public void destroy()
        {
            //this.isMove = false;
            //this.disableControl();
            //var _loc3 = Math.round(this.currentTank._x / 8);
            //var _loc4 = Math.round(this.currentTank._y / 8);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.clearTankMap(_loc3, _loc4);
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showBlast(this.currentTank._x, this.currentTank._y, "bigExplosive");
            //this.currentTank.removeMovieClip();
        }
    }
}
