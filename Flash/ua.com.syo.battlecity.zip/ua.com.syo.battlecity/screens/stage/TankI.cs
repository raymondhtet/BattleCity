﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class TankI : Flash.Clip
    {
        public TankI()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }
    }
}
