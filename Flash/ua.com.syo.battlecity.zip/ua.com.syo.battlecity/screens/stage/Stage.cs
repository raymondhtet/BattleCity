﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class Stage : Flash.Clip
    {
        public Stage()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //_loc1.playerBombDepth = 0;
            //_loc1.enemyBombDepth = 0;
            //_loc1.currentPortalForShowEnemy = 1;
            //_loc1.enemyIncr = 0;
            //_loc1.isGameOver = false;
            //_loc1.isEnemyStopped = false;
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.Stage", ua.com.syo.battlecity.screens.stage.Stage);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.Stage", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.Stage)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.stageMap = ua.com.syo.battlecity.screens.stage.StageMapView.create(this, "stage", this.getNextHighestDepth());
            //this.stageMap._x = 16;
            //this.stageMap._y = 8;
            //this.infoPanelView = ua.com.syo.battlecity.screens.stage.InfoPanelView.create(this, "nfoPanelView", this.getNextHighestDepth());
            //this.closerTop = this.attachMovie("closer", "closerTop", this.getNextHighestDepth());
            //this.closerBottom = this.attachMovie("closer", "closerBottom", this.getNextHighestDepth());
            //this.closerTop._y = 0;
            //this.closerBottom._y = 113;
            //this.gameOver = this.createEmptyMovieClip("gameOver", this.getNextHighestDepth());
            //this.goText1 = ua.com.syo.battlecity.components.NESTextField.create(this.gameOver, "goText1", this.gameOver.getNextHighestDepth());
            //this.goText2 = ua.com.syo.battlecity.components.NESTextField.create(this.gameOver, "goText2", this.gameOver.getNextHighestDepth());
            //this.pause_tf = ua.com.syo.battlecity.components.NESTextField.create(this, "pause_tf", this.getNextHighestDepth());
        }

        public void init()
        {
            //AsBroadcaster.initialize(this);
            //this.playerBombArray = new Array();
            //this.enemyArray = new Array();
            //this.infoPanelView.init();
            //this.stageMap.init();
            //this.stageMap.drawStage();
            //this.openStage();
            //this.tank = ua.com.syo.battlecity.screens.stage.Tank.create(this.stageMap.getTankContainer(), "tank", this.stageMap.getTankContainer().getNextHighestDepth());
            //this.goText1.init(105, 98, "game", 14166016);
            //this.goText2.init(105, 106, "over", 14166016);
            //this.pause_tf.init(101, 113, "pause", 14166016);
            //this.pause_tf._visible = false;
            //this.gameOver._visible = false;
            //Key.addListener(this);
        }

        public void openStage()
        {
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    if ($scope.closerBottom._y < 233)
            //    {
            //        $scope.closerTop._y = $scope.closerTop._y - 5;
            //        $scope.closerBottom._y = $scope.closerBottom._y + 5;
            //    }
            //    else
            //    {
            //        delete $scope.onEnterFrame;
            //    } // end else if
            //};
        }

        public void showTank()
        {
            //this.tank.init(ua.com.syo.battlecity.data.GlobalStorage.currentTankType);
        }

        public void showNextEnemy()
        {
            //var _loc2 = false;
            //var _loc3 = 0;
            //switch (this.currentPortalForShowEnemy)
            //{
            //    case 1:
            //        {
            //            if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(0, 0))
            //            {
            //                _loc3 = 0;
            //                _loc2 = true;
            //            } // end if
            //            break;
            //        }
            //    case 2:
            //        {
            //            if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(12, 0))
            //            {
            //                _loc3 = 96;
            //                _loc2 = true;
            //            } // end if
            //            break;
            //        }
            //    case 3:
            //        {
            //            if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(24, 0))
            //            {
            //                _loc3 = 192;
            //                _loc2 = true;
            //            } // end if
            //            break;
            //        }
            //} // End of switch
            //++this.currentPortalForShowEnemy;
            //if (this.currentPortalForShowEnemy > 3)
            //{
            //    this.currentPortalForShowEnemy = 1;
            //} // end if
            //if (_loc2)
            //{
            //    if (this.enemyIncr == ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //    {
            //        this.enemyIncr = 0;
            //    } // end if
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage;
            //    var _loc4 = ua.com.syo.battlecity.screens.stage.Enemy.create(this.stageMap.getEnemyContainer(), "enemy" + this.enemyIncr, this.enemyIncr);
            //    ++this.enemyIncr;
            //    _loc4.init(_loc3, ua.com.syo.battlecity.screens.stage.CurrentStageData.getNextEnemy());
            //} // end if
        }

        public void moveAllTanks()
        {
            //if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    this.tank.move();
            //    var _loc2 = 0;
                
            //    while (++_loc2, _loc2 < ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //    {
            //        if ((ua.com.syo.battlecity.screens.stage.Enemy)(this.stageMap.getEnemyContainer()["enemy" + _loc2]).getStatus() == "tank")
            //        {
            //            (ua.com.syo.battlecity.screens.stage.Enemy)(this.stageMap.getEnemyContainer()["enemy" + _loc2]).move(this.isEnemyStopped);
            //        } // end if
            //    } // end while
            //    _global.updateAfterEvent();
            //} // end if
        }

        public void moveAllBombs()
        {
            //if (!ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    var _loc2 = 0;
                
            //    while (++_loc2, _loc2 < 3)
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBombColision((ua.com.syo.battlecity.screens.stage.Bomb)(this.stageMap.getPlayerBombContainer()["bomb" + _loc2]));
            //        (ua.com.syo.battlecity.screens.stage.Bomb)(this.stageMap.getPlayerBombContainer()["bomb" + _loc2]).move();
            //    } // end while
            //    var _loc3 = 0;
                
            //    while (++_loc3, _loc3 < 20)
            //    {
            //        (ua.com.syo.battlecity.screens.stage.Bomb)(this.stageMap.getEnemyBombContainer()["bomb" + _loc3]).move();
            //    } // end while
            //    _global.updateAfterEvent();
            //} // end if
        }

        public void putPlayerBomb(Flash.var x, Flash.var y, Flash.var direction, Flash.var speed, Flash.var isFerumErase)
        {
            //if (!this.gameOver._visible)
            //{
            //    ++this.playerBombDepth;
            //    if (this.playerBombDepth == 3)
            //    {
            //        this.playerBombDepth = 0;
            //    } // end if
            //    var _loc7 = ua.com.syo.battlecity.screens.stage.Bomb.create(this.stageMap.getPlayerBombContainer(), "bomb" + this.playerBombDepth, this.playerBombDepth);
            //    _loc7.init(x, y, direction, speed, true, isFerumErase);
            //} // end if
        }

        public void putEnemyBomb()
        {
            //++this.enemyBombDepth;
            //if (this.enemyBombDepth == 20)
            //{
            //    this.enemyBombDepth = 0;
            //} // end if
            //var _loc6 = ua.com.syo.battlecity.screens.stage.Bomb.create(this.stageMap.getEnemyBombContainer(), "bomb" + this.enemyBombDepth, this.enemyBombDepth);
            //_loc6.init(x, y, direction, speed);
        }

        public void showBlast()
        {
            //var _loc5 = this.stageMap.getBlastContainer();
            //_loc5.attachMovie(type, "e" + _loc5.getNextHighestDepth(), _loc5.getNextHighestDepth(), {_x: x, _y: y});
        }

        public void showScore()
        {
            // var _loc5 = this.stageMap.getBlastContainer();
            //_loc5.attachMovie("score_" + value, "s" + _loc5.getNextHighestDepth(), _loc5.getNextHighestDepth(), {_x: x, _y: y});
        }

        public void putBonus()
        {
            //this.bonus.destroy();
            //this.bonus = ua.com.syo.battlecity.screens.stage.Bonus.create(this.stageMap.getBonusContainer(), "bonus", this.stageMap.getBonusContainer().getNextHighestDepth());
            //this.bonus.init(random(25), random(25), random(6));
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setBonusInstance(this.bonus);
        }

        public void onCheckBonus()
        {
            //var _loc2 = this.bonus.getType();
            //this.showScore(this.bonus.getX() * 8, this.bonus.getY() * 8, 500);
            //ua.com.syo.battlecity.data.GlobalStorage.score = ua.com.syo.battlecity.data.GlobalStorage.score + 500;
            //this.bonus.destroy();
            //switch (_loc2)
            //{
            //    case 0:
            //        {
            //            this.tank.upRank();
            //            break;
            //        }
            //    case 1:
            //        {
            //            this.bonusDestroyAllEnemy();
            //            break;
            //        }
            //    case 2:
            //        {
            //            this.bonusLifeAdd();
            //            break;
            //        }
            //    case 3:
            //        {
            //            this.bonusSetArmor();
            //            break;
            //        }
            //    case 4:
            //        {
            //            this.bonusStopTime();
            //            break;
            //        }
            //    case 5:
            //        {
            //            this.bonusBlockStuff();
            //            break;
            //        }
            //} // End of switch
        }

        public void bonusDestroyAllEnemy()
        {
            //var _loc2 = 0;
        
            //while (++_loc2, _loc2 < ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //{
            //    if ((ua.com.syo.battlecity.screens.stage.Enemy)(this.stageMap.getEnemyContainer()["enemy" + _loc2]).getStatus() == "tank")
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.destroyEnemy(this.stageMap.getEnemyContainer()["enemy" + _loc2], true);
            //    } // end if
            //} // end while
        }

        public void bonusLifeAdd()
        {
            //++ua.com.syo.battlecity.data.GlobalStorage.lifesNum;
            //this.infoPanelUpdate();
        }

        public void bonusSetArmor()
        {
            //this.tank.setArmor();
        }

        public void bonusStopTime()
        {
            //this.isEnemyStopped = true;
            //var $scope = this;
            //var onEF = this.createEmptyMovieClip("onEF", 10000);
            //$scope.enemyStoppedDelay = ua.com.syo.battlecity.data.GlobalStorage.enemyStoppedDelay;
            //onEF.onEnterFrame = function ()
            //{
            //    --$scope.enemyStoppedDelay;
            //    if ($scope.enemyStoppedDelay < 0)
            //    {
            //        $scope.isEnemyStopped = false;
            //        delete onEF.onEnterFrame;
            //    } // end if
            //};
        }

        public void bonusBlockStuff()
        {
            //this.fillStuff("f");
            //var $scope = this;
            //var onEF = this.createEmptyMovieClip("onEF", 10001);
            //this.blockStuffDelay = ua.com.syo.battlecity.data.GlobalStorage.blockStuffDelay;
            //onEF.onEnterFrame = function ()
            //{
            //    --$scope.blockStuffDelay;
            //    if ($scope.blockStuffDelay == 120 || ($scope.blockStuffDelay == 100 || ($scope.blockStuffDelay == 80 || ($scope.blockStuffDelay == 60 || ($scope.blockStuffDelay == 40 || $scope.blockStuffDelay == 20)))))
            //    {
            //        $scope.fillStuff("b");
            //    } // end if
            //    if ($scope.blockStuffDelay == 110 || ($scope.blockStuffDelay == 900 || ($scope.blockStuffDelay == 70 || ($scope.blockStuffDelay == 50 || ($scope.blockStuffDelay == 30 || $scope.blockStuffDelay == 10)))))
            //    {
            //        $scope.fillStuff("f");
            //    } // end if
            //    if ($scope.blockStuffDelay < 0)
            //    {
            //        $scope.fillStuff("b");
            //        delete onEF.onEnterFrame;
            //    } // end if
            //};
        }

        public void fillStuff(Flash.var type)
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(11, 25, type);
            //this.stageMap.setSpriteOnStage(11, 25, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(11, 24, type);
            //this.stageMap.setSpriteOnStage(11, 24, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(11, 23, type);
            //this.stageMap.setSpriteOnStage(11, 23, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(12, 23, type);
            //this.stageMap.setSpriteOnStage(12, 23, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(13, 23, type);
            //this.stageMap.setSpriteOnStage(13, 23, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(14, 23, type);
            //this.stageMap.setSpriteOnStage(14, 23, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(14, 24, type);
            //this.stageMap.setSpriteOnStage(14, 24, type);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(14, 25, type);
            //this.stageMap.setSpriteOnStage(14, 25, type);
        }

        public void infoPanelUpdate()
        {
            //var _loc2 = Math.round(20 / ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum() * ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyLeft());
            //this.infoPanelView.setEnemyLeft(_loc2);
            //this.infoPanelView.setLifes(ua.com.syo.battlecity.data.GlobalStorage.lifesNum - 1);
            //this.infoPanelView.setStageNum(ua.com.syo.battlecity.data.GlobalStorage.currentStage);
        }

        public void onAllEnemyKilled()
        {
            //var delayAfterStage = ua.com.syo.battlecity.data.GlobalStorage.delayAfterStage;
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    --delayAfterStage;
            //    if (delayAfterStage < 0)
            //    {
            //        $scope.stageComplete();
            //        delete $scope.onEnterFrame;
            //    } // end if
            //};
        }

        public void stageComplete()
        {
            this.broadcastMessage("onStageComplete");
        }

        public void onStaffDestroy()
        {
            //if (!this.isGameOver)
            //{
            //    this.isGameOver = true;
            //    this.showGameOver();
            //} // end if
        }

        public void onTankDestroy()
        {
            //--ua.com.syo.battlecity.data.GlobalStorage.lifesNum;
            //if (ua.com.syo.battlecity.data.GlobalStorage.lifesNum == 0)
            //{
            //    if (!this.isGameOver)
            //    {
            //        this.isGameOver = true;
            //        this.showGameOver();
            //    } // end if
            //}
            //else
            //{
            //    this.infoPanelUpdate();
            //    ua.com.syo.battlecity.data.GlobalStorage.currentTankType = 0;
            //    this.showTank();
            //} // end else if
        }

        public void showGameOver()
        {
            //this.gameOver._visible = true;
            //this.gameOver._y = 150;
            //var delayAfterGO = 100;
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    if ($scope.gameOver._y > 0)
            //    {
            //        $scope.gameOver._y = $scope.gameOver._y - 1;
            //    }
            //    else
            //    {
            //        $scope.tank.disableControl();
            //        if (delayAfterGO < 0)
            //        {
            //            $scope.doGameOver();
            //            delete $scope.onEnterFrame;
            //        }
            //        else
            //        {
            //            --delayAfterGO;
            //        } // end else if
            //    } // end else if
            //};
        }

        public void doGameOver()
        {
            this.broadcastMessage("onGameOver");
        }

        public void destroy()
        {
            this.removeMovieClip();
        }

        public void onKeyDown()
        {
            //if (Key.getCode() == 80)
            //{
            //    this.onPause();
            //} // end if
        }

        public void onPause()
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause = !ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause;
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause)
            //{
            //    this.tank.setOnPause();
            //    this.pause_tf._visible = true;
            //    var delay = 10;
            //    var $scope = this;
            //    this.pause_tf.onEnterFrame = function ()
            //    {
            //        --delay;
            //        if (delay < 0)
            //        {
            //            $scope.pause_tf._visible = !$scope.pause_tf._visible;
            //            delay = 10;
            //        } // end if
            //    };
            //}
            //else
            //{
            //    delete this.pause_tf.onEnterFrame;
            //    this.pause_tf._visible = false;
            //} // end else if
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
