﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class InfoPanelView : Flash.Clip
    {
        public InfoPanelView()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.InfoPanelView", ua.com.syo.battlecity.screens.stage.InfoPanelView);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.InfoPanelView", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.InfoPanelView)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.enemyLeftPanel = this.createEmptyMovieClip("enemyLeftPanel", this.getNextHighestDepth());
            //this.enemyLeftPanel._x = 233;
            //this.enemyLeftPanel._y = 17;
            //var _loc2 = 0;
            //var _loc3 = 0;
            
            //while (++_loc3, _loc3 < 10)
            //{
            //    var _loc4 = 0;
                
            //    while (++_loc4, _loc4 < 2)
            //    {
            //        ++_loc2;
            //        this.enemyLeftPanel.attachMovie("enemyIco", "ei" + _loc2, _loc2, {_x: _loc4 * 8, _y: _loc3 * 8});
            //    } // end while
            //} // end while
            //this.infoBlock = this.attachMovie("infoBlock", "infoBlock", this.getNextHighestDepth(), {_x: 230, _y: 128});
            //this.lifes_nf = ua.com.syo.battlecity.components.NESNumField.create(this, "lifes_nf", this.getNextHighestDepth());
            //this.stages_nf = ua.com.syo.battlecity.components.NESNumField.create(this, "stages_nf", this.getNextHighestDepth());
        }

        public void init()
        {
            //this.lifes_nf.init(240, 137, 2, "left", 0);
            //this.stages_nf.init(238, 192, 2, "left", 0);
        }

        public void setEnemyLeft(Flash.var enemyLeftNum)
        {
            //var _loc3 = 0;
            //var _loc4 = 0;
            
            //while (++_loc4, _loc4 < 10)
            //{
            //    var _loc5 = 0;
                
            //    while (++_loc5, _loc5 < 2)
            //    {
            //        ++_loc3;
            //        (MovieClip)(this.enemyLeftPanel["ei" + _loc3])._visible = _loc3 <= enemyLeftNum;
            //    } // end while
            //} // end while
        }

        public void setLifes(Flash.var lifesNum)
        {
            //this.lifes_nf.setValue(lifesNum.toString());
        }

        public void setStageNum(Flash.var stageNum)
        {
            //this.stages_nf.setValue(stageNum.toString());
        }
    }
}
