﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class StageMapView : Flash.Clip
    {
        public StageMapView()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.StageMapView", ua.com.syo.battlecity.screens.stage.StageMapView);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.StageMapView", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.StageMapView)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.blackBack = this.attachMovie("rectangle", "rectangle", 1);
            //this.blackBack._width = this.blackBack._height = 208;
            //this.iceCanvas = this.createEmptyMovieClip("ice", 2, {_x: 16, _y: 8});
            //this.waterCanvas = this.createEmptyMovieClip("water", 3, {_x: 16, _y: 8});
            //this.brickCanvas = this.createEmptyMovieClip("brick", 4, {_x: 16, _y: 8});
            //this.ferumCanvas = this.createEmptyMovieClip("ferum", 5, {_x: 16, _y: 8});
            //this.playerTankCanvas = this.createEmptyMovieClip("tank", 6, {_x: 16, _y: 8});
            //this.enemyTankCanvas = this.createEmptyMovieClip("enemy", 7, {_x: 16, _y: 8});
            //this.playerBombCanvas = this.createEmptyMovieClip("playerBomb", 8, {_x: 16, _y: 8});
            //this.enemyBombCanvas = this.createEmptyMovieClip("enemyBomb", 9, {_x: 16, _y: 8});
            //this.blastCanvas = this.createEmptyMovieClip("blast", 10, {_x: 16, _y: 8});
            //this.gardenCanvas = this.createEmptyMovieClip("blast", 11, {_x: 16, _y: 8});
            //this.bonusCanvas = this.createEmptyMovieClip("bonus", 11, {_x: 16, _y: 8});
        }

        public void init()
        {
        }

        public void drawStage()
        {
            //var _loc2 = 0;
        
            //while (++_loc2, _loc2 < 26)
            //{
            //    var _loc3 = 0;
                
            //    while (++_loc3, _loc3 < 26)
            //    {
            //        var _loc4 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(_loc2, _loc3);
            //        this.setSpriteOnStage(_loc2, _loc3, _loc4);
            //    } // end while
            //} // end while
        }

        public void setSpriteOnStage(Flash.var x, Flash.var y, Flash.var type)
        {
            //if (x == 12 && y == 24)
            //{
            //    this.eagle = this.ferumCanvas.attachMovie("eagle", "eagle", x * 100 + y, {_x: x * 8, _y: y * 8});
            //    this.eagle.gotoAndStop(1);
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.eagleInstance = this.eagle;
            //}
            //else
            //{
            //    (ua.com.syo.battlecity.components.Sprite)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getSpriteInstance(x, y)).destroy();
            //    switch (type)
            //    {
            //        case "b":
            //        {
            //            var _loc5 = ua.com.syo.battlecity.components.Sprite.create(this.brickCanvas, "b" + x + "_" + y, this.brickCanvas.getNextHighestDepth());
            //            _loc5.init(x * 8, y * 8, "brick");
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.setSpriteInstance(x, y, _loc5);
            //            break;
            //        } 
            //        case "f":
            //        {
            //            var _loc6 = ua.com.syo.battlecity.components.Sprite.create(this.ferumCanvas, "f" + x + "_" + y, this.ferumCanvas.getNextHighestDepth());
            //            _loc6.init(x * 8, y * 8, "ferum");
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.setSpriteInstance(x, y, _loc6);
            //            break;
            //        } 
            //        case "g":
            //        {
            //            var _loc7 = ua.com.syo.battlecity.components.Sprite.create(this.gardenCanvas, "g" + x + "_" + y, this.gardenCanvas.getNextHighestDepth());
            //            _loc7.init(x * 8, y * 8, "garden");
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.setSpriteInstance(x, y, _loc7);
            //            break;
            //        } 
            //        case "w":
            //        {
            //            var _loc8 = ua.com.syo.battlecity.components.Sprite.create(this.waterCanvas, "w" + x + "_" + y, this.waterCanvas.getNextHighestDepth());
            //            _loc8.init(x * 8, y * 8, "water");
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.setSpriteInstance(x, y, _loc8);
            //            break;
            //        } 
            //        case "i":
            //        {
            //            var _loc9 = ua.com.syo.battlecity.components.Sprite.create(this.iceCanvas, "i" + x + "_" + y, this.iceCanvas.getNextHighestDepth());
            //            _loc9.init(x * 8, y * 8, "ice");
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.setSpriteInstance(x, y, _loc9);
            //            break;
            //        } 
            //    } // End of switch
            //} // end else if
        }

        public void getTankContainer()
        {
            //return (this.playerTankCanvas);
        }

        public void getEnemyContainer()
        {
            //return (this.enemyTankCanvas);
        }

        public void getPlayerBombContainer()
        {
            //return (this.playerBombCanvas);
        }

        public void getEnemyBombContainer()
        {
            //return (this.enemyBombCanvas);
        }

        public void getBlastContainer()
        {
            //return (this.blastCanvas);
        }

        public void getBonusContainer()
        {
            //return (this.bonusCanvas);
        }
    }
}
