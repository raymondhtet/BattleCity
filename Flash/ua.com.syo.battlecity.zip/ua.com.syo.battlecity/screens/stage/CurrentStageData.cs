﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class CurrentStageData : Flash.Clip
    {
        //stageMap_array = new Array<CurrentStageData>();
        //spriteNamesMap_array = new Array<CurrentStageData>();
        //allTanks_array = new Array<CurrentStageData>();
        //playerBombs_array = new Array<CurrentStageData>();
        //enemyBombs_array = new Array<CurrentStageData>();
        //enemysOrder_array = new Array();
        //currentPlayerBombNum = 0;
        //currentEnemy = 0;
        //enemyOnStage = 0;
        //isPause = false;

        public CurrentStageData()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void init()
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array = new Array(26);
            //var _loc2 = 0;
            
            //while (++_loc2, _loc2 < 26)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[_loc2] = new Array(26);
            //} // end while
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.spriteNamesMap_array = new Array(26);
            //var _loc3 = 0;
            
            //while (++_loc3, _loc3 < 26)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.spriteNamesMap_array[_loc3] = new Array(26);
            //} // end while
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array = new Array(26);
            //var _loc4 = 0;
            
            //while (++_loc4, _loc4 < 26)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[_loc4] = new Array(26);
            //} // end while
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.playerBombs_array = new Array(26);
            //var _loc5 = 0;
            
            //while (++_loc5, _loc5 < 26)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.playerBombs_array[_loc5] = new Array(26);
            //} // end while
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array = new Array(26);
            //var _loc6 = 0;
            
            //while (++_loc6, _loc6 < 26)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc6] = new Array(26);
            //} // end while
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.enemysOrder_array = new Array();
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array = new Array(0, 0, 0, 0);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.currentPlayerBombNum = 0;
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.currentEnemy = 0;
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage = 0;
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum = 0;
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.isPause = false;
        }

        public void fillMap(Flash.XML xml)
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.init();
            //var _loc3 = xml.childNodes[0];
            //var _loc4 = 0;
            
            //while (++_loc4, _loc4 < 26)
            //{
            //    var _loc5 = new String((XMLNode)(_loc3.childNodes[_loc4]).childNodes.toString());
            //    var _loc6 = 0;
                
            //    while (++_loc6, _loc6 < 26)
            //    {
            //        (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[_loc6])[_loc4] = _loc5.charAt(_loc6);
            //        (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[_loc6])[_loc4] = null;
            //        (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc6])[_loc4] = null;
            //    } // end while
            //} // end while
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[24] = "o";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[25] = "o";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[24] = "o";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[25] = "o";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[11])[25] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[11])[24] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[11])[23] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[23] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[23] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[14])[23] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[14])[24] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[14])[25] = "b";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[0])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[0])[1] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[1])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[1])[1] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[1] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[1] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[24])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[24])[1] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[25])[0] = "_";
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[25])[1] = "_";
            //var _loc7 = new String(_loc3.attributes.enemys);
            //var _loc8 = 0;
            
            //while (++_loc8, _loc8 < _loc7.length)
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.enemysOrder_array[_loc8] = _loc7.charAt(_loc8);
            //} // end while
        }

        public void setSprite(Flash.var x, Flash.var y, Flash.var type)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[x])[y] = type;
        }

        public void getSprite(Flash.var x, Flash.var y)
        {
            //return ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[x])[y]);
        }

        public void setSpriteInstance(Flash.var x, Flash.var y, Flash.var sprite)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.spriteNamesMap_array[x])[y] = sprite;
        }

        public void getSpriteInstance(Flash.var x, Flash.var y)
        {
            //return ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.spriteNamesMap_array[x])[y]);
        }

        public void checkBarrierForTank(Flash.var x, Flash.var y)
        {
            //var _loc4 = false;
            //var _loc5 = false;
            //var _loc6 = false;
            //var _loc7 = false;
            //var _loc8 = false;
            //var _loc9 = false;
            //var _loc10 = false;
            //var _loc11 = false;
            //var _loc12 = new Array("_", "g", "i");
            //var _loc13 = 0;
            
            //while (++_loc13, _loc13 < _loc12.length)
            //{
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == _loc12[_loc13])
            //    {
            //        _loc4 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x + 1, y) == _loc12[_loc13])
            //    {
            //        _loc5 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y + 1) == _loc12[_loc13])
            //    {
            //        _loc6 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x + 1, y + 1) == _loc12[_loc13])
            //    {
            //        _loc7 = true;
            //    } // end if
            //} // end while
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankMapState(x, y))
            //{
            //    _loc8 = true;
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankMapState(x + 1, y))
            //{
            //    _loc9 = true;
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankMapState(x, y + 1))
            //{
            //    _loc10 = true;
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankMapState(x + 1, y + 1))
            //{
            //    _loc11 = true;
            //} // end if
            //return (_loc4 && (_loc5 && (_loc6 && (_loc7 && (_loc8 && (_loc9 && (_loc10 && _loc11)))))));
        }

        public void checkIce(Flash.var x, Flash.var y)
        {
            //var _loc4 = false;
            //var _loc5 = false;
            //var _loc6 = false;
            //var _loc7 = false;
            //var _loc8 = new Array("i");
            //var _loc9 = 0;
            
            //while (++_loc9, _loc9 < _loc8.length)
            //{
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == _loc8[_loc9])
            //    {
            //        _loc4 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x + 1, y) == _loc8[_loc9])
            //    {
            //        _loc5 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y + 1) == _loc8[_loc9])
            //    {
            //        _loc6 = true;
            //    } // end if
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x + 1, y + 1) == _loc8[_loc9])
            //    {
            //        _loc7 = true;
            //    } // end if
            //} // end while
            //return (_loc4 && (_loc5 && (_loc6 && _loc7)));
        }

        public void checkBarrierForBomb(Flash.var x, Flash.var y, Flash.var direction)
        {
            //var _loc5 = false;
            //var _loc6 = false;
            //var _loc7 = new Array("_", "g", "i", "w");
            //var _loc8 = 0;
            
            //while (++_loc8, _loc8 < _loc7.length)
            //{
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == _loc7[_loc8])
            //    {
            //        _loc5 = true;
            //    } // end if
            //    switch (direction)
            //    {
            //        case 1:
            //        {
            //            var _loc9 = x + 1;
            //            var _loc10 = y;
            //            break;
            //        } 
            //        case 2:
            //        {
            //            _loc9 = x + 1;
            //            _loc10 = y;
            //            break;
            //        } 
            //        case 3:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        } 
            //        case 4:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        } 
            //    } // End of switch
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(_loc9, _loc10) == _loc7[_loc8])
            //    {
            //        _loc6 = true;
            //    } // end if
            //} // end while
            //return (_loc5 && _loc6);
        }

        public void eraseBrick(Flash.var x, Flash.var y, Flash.var direction, Flash.var isEraseFerum)
        {
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == "b")
            //{
            //    var _loc6 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getSpriteInstance(x, y);
            //    var _loc7 = _loc6.nextErase(direction);
            //    if (_loc7 || isEraseFerum)
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(x, y, "_");
            //        _loc6.destroy();
            //    } // end if
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == "f" && isEraseFerum)
            //{
            //    var _loc8 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getSpriteInstance(x, y);
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(x, y, "_");
            //    _loc8.destroy();
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(x, y) == "o")
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.eagleInstance.gotoAndStop(2);
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showBlast(96, 192, "bigExplosive");
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onStaffDestroy();
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[24] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[25] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[24] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[25] = "w";
            //} // end if
            //switch (direction)
            //{
            //    case 1:
            //        {
            //            var _loc9 = x + 1;
            //            var _loc10 = y;
            //            break;
            //        }
            //    case 2:
            //        {
            //            _loc9 = x + 1;
            //            _loc10 = y;
            //            break;
            //        }
            //    case 3:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        }
            //    case 4:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        }
            //} // End of switch
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(_loc9, _loc10) == "b")
            //{
            //    var _loc11 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getSpriteInstance(_loc9, _loc10);
            //    var _loc12 = _loc11.nextErase(direction);
            //    if (_loc12 || isEraseFerum)
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(_loc9, _loc10, "_");
            //        _loc11.destroy();
            //    } // end if
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(_loc9, _loc10) == "f" && isEraseFerum)
            //{
            //    var _loc13 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getSpriteInstance(_loc9, _loc10);
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.setSprite(_loc9, _loc10, "_");
            //    _loc13.destroy();
            //} // end if
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.getSprite(_loc9, _loc10) == "o")
            //{
            //    ua.com.syo.battlecity.screens.stage.CurrentStageData.eagleInstance.gotoAndStop(2);
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showBlast(96, 192, "bigExplosive");
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onStaffDestroy();
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[24] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[12])[25] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[24] = "w";
            //    (Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.stageMap_array[13])[25] = "w";
            //} // end if
        }

        public void checkEnemyForBomb(Flash.var x, Flash.var y, Flash.var direction)
        {
            //var _loc5 = false;
            //var _loc6 = false;
            //var _loc7 = false;
            //var _loc8 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(x, y);
            //if (_loc8 == null || ((ua.com.syo.battlecity.screens.stage.TankI)(_loc8).getType() == "player" || (ua.com.syo.battlecity.screens.stage.TankI)(_loc8).getStatus() == "portal"))
            //{
            //    _loc5 = true;
            //}
            //else if ((ua.com.syo.battlecity.screens.stage.Enemy)(_loc8).getModel() == 4)
            //{
            //    _loc7 = true;
            //    (ua.com.syo.battlecity.screens.stage.Enemy)(_loc8).changeRankFor4();
            //    if ((ua.com.syo.battlecity.screens.stage.Enemy)(_loc8).getRankFor4() < 0)
            //    {
            //        ua.com.syo.battlecity.screens.stage.CurrentStageData.destroyEnemy(_loc8);
            //    } // end if
            //}
            //else
            //{
            //    --ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage;
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array[(ua.com.syo.battlecity.screens.stage.Enemy)(_loc8).getModel() - 1];
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum;
            //    (ua.com.syo.battlecity.screens.stage.TankI)(_loc8).destroy();
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum == ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //    {
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onAllEnemyKilled();
            //    } // end else if
            //} // end else if
            //switch (direction)
            //{
            //    case 1:
            //        {
            //            var _loc9 = x + 1;
            //            var _loc10 = y;
            //            break;
            //        }
            //    case 2:
            //        {
            //            _loc9 = x + 1;
            //            _loc10 = y;
            //            break;
            //        }
            //    case 3:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        }
            //    case 4:
            //        {
            //            _loc9 = x;
            //            _loc10 = y + 1;
            //            break;
            //        }
            //} // End of switch
            //var _loc11 = ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(_loc9, _loc10);
            //if (_loc11 == null || ((ua.com.syo.battlecity.screens.stage.TankI)(_loc11).getType() == "player" || (ua.com.syo.battlecity.screens.stage.TankI)(_loc11).getStatus() == "portal"))
            //{
            //    _loc6 = true;
            //}
            //else if ((ua.com.syo.battlecity.screens.stage.Enemy)(_loc11).getModel() == 4)
            //{
            //    if (_loc7 && _loc8 == _loc11)
            //    {
            //    }
            //    else
            //    {
            //        (ua.com.syo.battlecity.screens.stage.Enemy)(_loc11).changeRankFor4();
            //        if ((ua.com.syo.battlecity.screens.stage.Enemy)(_loc11).getRankFor4() < 0)
            //        {
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.destroyEnemy(_loc11);
            //        } // end if
            //    } // end else if
            //}
            //else
            //{
            //    --ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage;
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array[(ua.com.syo.battlecity.screens.stage.Enemy)(_loc11).getModel() - 1];
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum;
            //    (ua.com.syo.battlecity.screens.stage.TankI)(_loc11).destroy();
            //    if (ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum == ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //    {
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onAllEnemyKilled();
            //    } // end else if
            //} // end else if
            //return (_loc5 && _loc6);
        }

        public void destroyEnemy(Flash.var enemy, Flash.var isGrenade)
        {
            //--ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyOnStage;
            //if (!isGrenade)
            //{
            //    ++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array[(ua.com.syo.battlecity.screens.stage.Enemy)(enemy).getModel() - 1];
            //} // end if
            //++ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum;
            //(ua.com.syo.battlecity.screens.stage.Enemy)(enemy).destroy(isGrenade);
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKillNum == ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum())
            //{
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onAllEnemyKilled();
            //} // end if
        }

        public void checkPlayerForBomb(Flash.var x, Flash.var y, Flash.var direction, Flash.var instance)
        {
            //var _loc6 = false;
            //var _loc7 = false;
            //if ((ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(x, y)).getType() == "player" && (ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(x, y)).getStatus() == "tank")
            //{
            //    (ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(x, y)).destroy();
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onTankDestroy();
            //}
            //else if ((ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(x, y)).getStatus() == "armor")
            //{
            //    instance.destroy();
            //}
            //else
            //{
            //    _loc6 = true;
            //} // end else if
            //switch (direction)
            //{
            //    case 1:
            //        {
            //            var _loc8 = x + 1;
            //            var _loc9 = y;
            //            break;
            //        }
            //    case 2:
            //        {
            //            _loc8 = x + 1;
            //            _loc9 = y;
            //            break;
            //        }
            //    case 3:
            //        {
            //            _loc8 = x;
            //            _loc9 = y + 1;
            //            break;
            //        }
            //    case 4:
            //        {
            //            _loc8 = x;
            //            _loc9 = y + 1;
            //            break;
            //        }
            //} // End of switch
            //if ((ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(_loc8, _loc9)).getType() == "player" && (ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(_loc8, _loc9)).getStatus() == "tank")
            //{
            //    (ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(_loc8, _loc9)).destroy();
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().onTankDestroy();
            //}
            //else if ((ua.com.syo.battlecity.screens.stage.TankI)(ua.com.syo.battlecity.screens.stage.CurrentStageData.getTankFromMap(_loc8, _loc9)).getStatus() == "armor")
            //{
            //    instance.destroy();
            //}
            //else
            //{
            //    _loc7 = true;
            //} // end else if
            //return (_loc6 && _loc7);
        }

        public void checkBombColision(Flash.var bombInstance)
        {
            //var _loc3 = Math.round(bombInstance.x / 8);
            //var _loc4 = Math.round(bombInstance.y / 8);
            //if ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc3])[_loc4] != null)
            //{
            //    bombInstance.destroy(true);
            //    (ua.com.syo.battlecity.screens.stage.Bomb)((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc3])[_loc4]).destroy(true);
            //}
            //else
            //{
            //    var _loc5 = bombInstance.direction;
            //    switch (_loc5)
            //    {
            //        case 1:
            //            {
            //                --_loc4;
            //                break;
            //            }
            //        case 2:
            //            {
            //                ++_loc4;
            //                break;
            //            }
            //        case 3:
            //            {
            //                --_loc3;
            //                break;
            //            }
            //        case 4:
            //            {
            //                ++_loc3;
            //                break;
            //            }
            //    } // End of switch
            //    if ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc3])[_loc4] != null)
            //    {
            //        bombInstance.destroy(true);
            //        (ua.com.syo.battlecity.screens.stage.Bomb)((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[_loc3])[_loc4]).destroy(true);
            //    } // end if
            //} // end else if
        }

        public void fillTankMap(Flash.var x, Flash.var y, Flash.var instance)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y] = instance;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x + 1])[y] = instance;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y + 1] = instance;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x + 1])[y + 1] = instance;
        }

        public void clearTankMap(Flash.var x, Flash.var y)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y] = null;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x + 1])[y] = null;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y + 1] = null;
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x + 1])[y + 1] = null;
        }

        public void fillBombMap(Flash.var x, Flash.var y, Flash.var instance)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[x])[y] = instance;
        }

        public void clearBombMap(Flash.var x, Flash.var y)
        {
            //(Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyBombs_array[x])[y] = null;
        }

        public void getTankFromMap(Flash.var x, Flash.var y)
        {
            //return ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y]);
        }

        public void getTankMapState(Flash.var x, Flash.var y)
        {
            //if ((Array)(ua.com.syo.battlecity.screens.stage.CurrentStageData.allTanks_array[x])[y] == null)
            //{
            //    return (true);
            //}
            //else
            //{
            //    return (false);
            //} // end else if
        }

        public void getNextEnemy(Flash.var pos)
        {
            //if (pos == undefined)
            //{
            //    pos = ua.com.syo.battlecity.screens.stage.CurrentStageData.currentEnemy;
            //} // end if
            //++ua.com.syo.battlecity.screens.stage.CurrentStageData.currentEnemy;
            //return (Number(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemysOrder_array[pos]));
        }

        public void getEnemyNum()
        {
            //return (ua.com.syo.battlecity.screens.stage.CurrentStageData.enemysOrder_array.length);
        }

        public void getEnemyLeft()
        {
            //return (ua.com.syo.battlecity.screens.stage.CurrentStageData.getEnemyNum() - ua.com.syo.battlecity.screens.stage.CurrentStageData.currentEnemy);
        }

        public void setBonusInstance(Flash.var b)
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.bonus = b;
        }

        public void getBonusInstance()
        {
            //return (ua.com.syo.battlecity.screens.stage.CurrentStageData.bonus);
        }

        public void checkBonusCollision(Flash.var tank)
        {
            //if (ua.com.syo.battlecity.screens.stage.CurrentStageData.bonus.hitTest(tank))
            //{
            //    return (true);
            //}
            //else
            //{
            //    return (false);
            //} // end else if
        }
    }
}
