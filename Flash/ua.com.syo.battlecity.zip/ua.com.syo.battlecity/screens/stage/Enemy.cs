﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens.stage
{
    public class Enemy : Flash.Clip
    {
        public Enemy()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //_loc1.direction = 1;
            //_loc1.direction_array = new Array("up", "down", "left", "right");
            //_loc1.keyStack_array = new Array();
            //_loc1.delay = 0;
            //_loc1.shootDelay = random(50);
            //_loc1.blinkingDelay = 10;
            //_loc1.isBonus = false;
            //_loc1.isMove = false;
            //_loc1.isPortalView = true;
            //_loc1.isMoveFor4 = true;
            //_loc1.leftShootFor4 = 3;
            //_loc1.tankSpeed_array = new Array(1, 2, 1, 1);
            //_loc1.bombSpeed_array = new Array(2, 2, 3, 2);
            //_loc1.bonusColors_array = new Array(9175156, 14166016, 16579836);
            //_loc1.bigTankColors1_1_array = new Array(20480, 36920, 11599052);
            //_loc1.bigTankColors1_2_array = new Array(20480, 36920, 11599052);
            //_loc1.bigTankColors2_1_array = new Array(8941568, 16554040, 16573600);
            //_loc1.bigTankColors2_2_array = new Array(8941568, 16554040, 16573600);
            //_loc1.bigTankColors3_1_array = new Array(8941568, 16554040, 16573600);
            //_loc1.bigTankColors3_2_array = new Array(20480, 36920, 11599052);
            //_loc1.bigTankColors4_1_array = new Array(1588316, 12369084, 16579836);
            //_loc1.bigTankColors4_2_array = new Array(1588316, 12369084, 16579836);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.stage.Enemy", ua.com.syo.battlecity.screens.stage.Enemy);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.stage.Enemy", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.stage.Enemy)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
        }

        public void init(Flash.var startX, Flash.var type)
        {
            //this.startX = startX;
            //this.type = type;
            //if (this.type > 4)
            //{
            //    this.type = this.type - 4;
            //    this.isBonus = true;
            //} // end if
            //var _loc4 = Math.round(this.startX / 8);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc4, 0, this);
            //this.putOnStartPosition();
        }

        public void putOnStartPosition()
        {
            //this.showPortal();
        }

        public void showPortal()
        {
            //this.portal = this.attachMovie("portalTank", "portal", this.getNextHighestDepth(), {_x: this.startX, _y: 0});
            //this.portal.scope = this;
            //this.portal.gotoAndPlay(1);
        }

        public void onPortalHide()
        {
            //this.showEnemy();
            //this.portal.removeMovieClip();
            //this.isPortalView = false;
        }

        public void showEnemy()
        {
            //this.currentTank = this.attachMovie("enemy" + this.type, "enemy", this.getNextHighestDepth());
            //this.currentTank._x = this.startX;
            //this.currentTank._y = 0;
            //this.arrangeTank();
            //this.isMove = true;
        }

        public void arrangeTank()
        {
            //this.currentTank.gotoAndStop(this.direction_array[this.direction - 1]);
            //if (this.direction == 1 || this.direction == 2)
            //{
            //    this.currentTank._x = Math.round(this.currentTank._x / 8) * 8;
            //}
            //else
            //{
            //    this.currentTank._y = Math.round(this.currentTank._y / 8) * 8;
            //} // end else if
        }

        public void move(Flash.var isStopped)
        {
            //if (this.isMove)
            //{
            //    if (!isStopped)
            //    {
            //        --this.delay;
            //    } // end if
            //    if (this.delay < 0)
            //    {
            //        this.changeDirection();
            //    }
            //    else
            //    {
            //        this.isMoveFor4 = !this.isMoveFor4;
            //        if (this.isMoveFor4 || this.type != 4)
            //        {
            //            var _loc5 = Math.round(this.currentTank._x / 8);
            //            var _loc6 = Math.round(this.currentTank._y / 8);
            //            ua.com.syo.battlecity.screens.stage.CurrentStageData.clearTankMap(_loc5, _loc6);
            //            if (!isStopped)
            //            {
            //                var _loc7 = this.currentTank._x + this.dx * this.tankSpeed_array[this.type - 1];
            //                var _loc8 = this.currentTank._y + this.dy * this.tankSpeed_array[this.type - 1];
            //            }
            //            else
            //            {
            //                _loc7 = this.currentTank._x;
            //                _loc8 = this.currentTank._y;
            //            } // end else if
            //            if (this.direction == 1 || this.direction == 3)
            //            {
            //                var _loc3 = Math.floor(_loc7 / 8);
            //                var _loc4 = Math.floor(_loc8 / 8);
            //            }
            //            else
            //            {
            //                _loc3 = Math.ceil(_loc7 / 8);
            //                _loc4 = Math.ceil(_loc8 / 8);
            //            } // end else if
            //            if (ua.com.syo.battlecity.screens.stage.CurrentStageData.checkBarrierForTank(_loc3, _loc4))
            //            {
            //                this.currentTank._x = _loc7;
            //                this.currentTank._y = _loc8;
            //                _loc3 = Math.round(_loc7 / 8);
            //                _loc4 = Math.round(_loc8 / 8);
            //                ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc3, _loc4, this);
            //            }
            //            else
            //            {
            //                if (!isStopped)
            //                {
            //                    this.delay = this.delay - 2;
            //                } // end if
            //                ua.com.syo.battlecity.screens.stage.CurrentStageData.fillTankMap(_loc5, _loc6, this);
            //            } // end else if
            //            if (!isStopped)
            //            {
            //                var _loc9 = this.currentTank._currentframe / 2;
            //                if (_loc9 - Math.round(_loc9) == 0)
            //                {
            //                    this.currentTank.prevFrame();
            //                }
            //                else
            //                {
            //                    this.currentTank.nextFrame();
            //                } // end if
            //            } // end else if
            //            this.blink();
            //        } // end if
            //    } // end else if

            //    if (!isStopped)
            //    {
            //        --this.shootDelay;
            //        if (this.shootDelay < 0)
            //        {
            //            ua.com.syo.battlecity.controller.GameController.getInstance().putEnemyBomb(this.currentTank._x, this.currentTank._y, this.direction, this.bombSpeed_array[this.type - 1]);
            //            this.shootDelay = random(ua.com.syo.battlecity.data.GlobalStorage.enemyShootDelay) + ua.com.syo.battlecity.data.GlobalStorage.enemyShootDelay;
            //        } // end if
            //    } // end if
            //} // end if
        }

        public void changeDirection()
        {
            //var _loc2 = this.direction;
            //var _loc3 = random(10);
            //if (_loc3 < 2)
            //{
            //    _loc2 = this.direction = 2;
            //}
            //else if (_loc3 < 4)
            //{
            //    if (this.currentTank._x > 104)
            //    {
            //        _loc2 = 3;
            //    }
            //    else
            //    {
            //        _loc2 = 4;
            //    } // end else if
            //}
            //else
            //{
            //    _loc2 = random(4) + 1;
            //} // end else if

            //switch (_loc2)
            //{
            //    case 1:
            //        {
            //            this.dx = 0;
            //            this.dy = -1;
            //            this.direction = 1;
            //            break;
            //        }
            //    case 2:
            //        {
            //            this.dx = 0;
            //            this.dy = 1;
            //            this.direction = 2;
            //            break;
            //        }
            //    case 3:
            //        {
            //            this.dx = -1;
            //            this.dy = 0;
            //            this.direction = 3;
            //            break;
            //        }
            //    case 4:
            //        {
            //            this.dx = 1;
            //            this.dy = 0;
            //            this.direction = 4;
            //            break;
            //        }
            //    case 32:
            //} // End of switch

            //this.delay = random(ua.com.syo.battlecity.data.GlobalStorage.enemychangeDirectionDelay) + 10;
            //this.arrangeTank();
        }

        public void blink()
        {
            //var _loc2 = new Array();
            //var _loc3 = new Array();
            //if (this.type == 4)
            //{
            //    switch (this.leftShootFor4)
            //    {
            //        case 3:
            //            {
            //                if (this.isBonus)
            //                {
            //                    _loc2 = this.bonusColors_array;
            //                    _loc3 = this.bigTankColors4_2_array;
            //                }
            //                else
            //                {
            //                    _loc2 = this.bigTankColors1_1_array;
            //                    _loc3 = this.bigTankColors1_2_array;
            //                } // end else if
            //                break;
            //            }
            //        case 2:
            //            {
            //                _loc2 = this.bigTankColors2_1_array;
            //                _loc3 = this.bigTankColors2_2_array;
            //                break;
            //            }
            //        case 1:
            //            {
            //                _loc2 = this.bigTankColors3_1_array;
            //                _loc3 = this.bigTankColors3_2_array;
            //                break;
            //            }
            //        case 0:
            //            {
            //                _loc2 = this.bigTankColors4_1_array;
            //                _loc3 = this.bigTankColors4_2_array;
            //                break;
            //            }
            //    } // End of switch
            //}
            //else if (this.isBonus)
            //{
            //    _loc2 = this.bonusColors_array;
            //    _loc3 = this.bigTankColors4_2_array;
            //}
            //else
            //{
            //    _loc2 = this.bigTankColors4_1_array;
            //    _loc3 = this.bigTankColors4_2_array;
            //} // end else if
            //--this.blinkingDelay;
            //var _loc4 = new Color(this.currentTank.black_mc);
            //var _loc5 = new Color(this.currentTank.silver_mc);
            //var _loc6 = new Color(this.currentTank.white_mc);
            //if (this.blinkingDelay < 0)
            //{
            //    _loc4.setRGB(_loc2[0]);
            //    _loc5.setRGB(_loc2[1]);
            //    _loc6.setRGB(_loc2[2]);
            //}
            //else
            //{
            //    _loc4.setRGB(_loc3[0]);
            //    _loc5.setRGB(_loc3[1]);
            //    _loc6.setRGB(_loc3[2]);
            //} // end else if
            //if (this.blinkingDelay < -5)
            //{
            //    this.blinkingDelay = 10;
            //} // end if
        }

        public void getType()
        {
            //return ("enemy");
        }

        public void getModel()
        {
            //return (this.type);
        }

        public void changeRankFor4()
        {
            //--this.leftShootFor4;
            //if (this.leftShootFor4 == 2 && this.isBonus)
            //{
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().putBonus();
            //} // end if
        }

        public void getRankFor4()
        {
            //return (this.leftShootFor4);
        }

        public void destroy(Flash.var isGrenade)
        {
            //this.isMove = false;
            //var _loc3 = Math.round(this.currentTank._x / 8);
            //var _loc4 = Math.round(this.currentTank._y / 8);
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.clearTankMap(_loc3, _loc4);
            //ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showBlast(this.currentTank._x, this.currentTank._y, "bigExplosive");
            //if (!isGrenade)
            //{
            //    ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().showScore(this.currentTank._x, this.currentTank._y, 100 * this.type);
            //    ua.com.syo.battlecity.data.GlobalStorage.score = ua.com.syo.battlecity.data.GlobalStorage.score + 100 * this.type;
            //    if (this.isBonus && this.type != 4)
            //    {
            //        ua.com.syo.battlecity.view.UIManager.getInstance().getStageInstance().putBonus();
            //    } // end if
            //} // end if
            //this.removeMovieClip();
        }

        public void getStatus()
        {
            //if (this.isPortalView)
            //{
            //    return ("portal");
            //}
            //else
            //{
            //    return ("tank");
            //} // end else if
        }
    }
}
