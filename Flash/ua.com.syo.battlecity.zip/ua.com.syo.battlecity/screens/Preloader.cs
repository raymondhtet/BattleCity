﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens
{
    public class Preloader : Flash.Clip
    {
        public Preloader()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.Preloader", ua.com.syo.battlecity.screens.Preloader);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.Preloader", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.Preloader)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.title_tf = ua.com.syo.battlecity.components.NESTextField.create(this, "title_tf", this.getNextHighestDepth());
            //this.loading_tf = ua.com.syo.battlecity.components.NESTextField.create(this, "loading_tf", this.getNextHighestDepth());
            //this.proc_nf = ua.com.syo.battlecity.components.NESNumField.create(this, "proc_nf", this.getNextHighestDepth());
        }

        public void init()
        {
            //this.title_tf.init(82, 96, ua.com.syo.battlecity.data.DataLabels.PRELOADER_TITLE, 16777215);
            //this.loading_tf.init(82, 110, ua.com.syo.battlecity.data.DataLabels.PRELOADER_STATUS, 0);
            //this.proc_nf.init(145, 110, 3, "right", 16777215);
        }

        public void update(Flash.var loaded, Flash.var total)
        {
            //var _loc4 = loaded / total * 100;
            //this.proc_nf.setValue(_loc4.toString());
        }

        public void remove()
        {
            this.removeMovieClip();
        }
    }
}
