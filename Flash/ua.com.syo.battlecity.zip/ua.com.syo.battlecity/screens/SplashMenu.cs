﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens
{
    public class SplashMenu : Flash.Clip
    {
        public SplashMenu()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.SplashMenu", ua.com.syo.battlecity.screens.SplashMenu);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.SplashMenu", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.SplashMenu)(_loc6);
            //(ua.com.syo.battlecity.screens.SplashMenu)(_loc6).buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.attachMovie("rectangle", "rectangle", this.getNextHighestDepth());
            //this.canvas_mc = this.createEmptyMovieClip("canvas_mc", this.getNextHighestDepth());
            //this.bulletTank = this.attachMovie("bulletTank", "bulletTank", this.getNextHighestDepth());
            //this.bulletTank._visible = false;
            //this.bulletTank._x = 63;
            //this.bulletTank._y = 123;
            //this.closerTop = this.attachMovie("closer", "closerTop", this.getNextHighestDepth());
            //this.closerBottom = this.attachMovie("closer", "closerBottom", this.getNextHighestDepth());
            //this.closerTop._y = -121;
            //this.closerBottom._y = 233;
            //this.canvas_mc.attachMovie("gameTitle", "gameTitle", this.canvas_mc.getNextHighestDepth(), {_x: 28, _y: 40});
            //this.hiScore = ua.com.syo.battlecity.components.NESNumField.create(this.canvas_mc, "hiScore", this.canvas_mc.getNextHighestDepth());
            //this.onePl_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "onePl_tf", this.canvas_mc.getNextHighestDepth());
            //this.onePlHi_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "onePlHi_tf", this.canvas_mc.getNextHighestDepth());
            //this.onePlayer_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "onePlayer_tf", this.canvas_mc.getNextHighestDepth());
            //this.twoPlayer_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "twoPlayer_tf", this.canvas_mc.getNextHighestDepth());
            //this.construction_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "construction_tf", this.canvas_mc.getNextHighestDepth());
            //this.namcoCopy_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "namcoCopy_tf", this.canvas_mc.getNextHighestDepth());
            //this.allRight_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "allRight_tf", this.canvas_mc.getNextHighestDepth());
            //this.syoCopy_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "syoCopy_tf", this.canvas_mc.getNextHighestDepth());
            //this.version_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "version_tf", this.canvas_mc.getNextHighestDepth());
        }

        public void init()
        {
            //AsBroadcaster.initialize(this);
            //this.onePl_tf.init(17, 16, ua.com.syo.battlecity.data.DataLabels.SPLASH_ONE_PL, 16777215);
            //this.onePlHi_tf.init(88, 16, ua.com.syo.battlecity.data.DataLabels.SPLASH_ONE_PL_HI, 16777215);
            //this.onePlayer_tf.init(90, 128, ua.com.syo.battlecity.data.DataLabels.SPLASH_ONE_PLAYER, 16777215);
            //this.twoPlayer_tf.init(90, 144, ua.com.syo.battlecity.data.DataLabels.SPLASH_TWO_PLAYER, 10066329);
            //this.construction_tf.init(90, 160, ua.com.syo.battlecity.data.DataLabels.SPLASH_CONSTRUCTION, 10066329);
            //this.namcoCopy_tf.init(33, 176, ua.com.syo.battlecity.data.DataLabels.SPLASH_NAMCO_COPYRIGHT, 16777215);
            //this.allRight_tf.init(49, 192, ua.com.syo.battlecity.data.DataLabels.SPLASH_ALL_RIGHT, 16777215);
            //this.syoCopy_tf.init(49, 208, ua.com.syo.battlecity.data.DataLabels.SPLASH_SYO_COPYRIGHT, 16777215);
            //this.version_tf.init(180, 16, ua.com.syo.battlecity.data.DataLabels.SPLASH_VERSION, 6710886);
            //this.hiScore.init(120, 16, 8, "left", 16777215);
            //this.hiScore.setValue("20000");
            //this.canvas_mc._y = 232;
            //this.moveUp();
            //Key.addListener(this);
        }

        public void moveUp()
        {
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    if ($scope.canvas_mc._y > 0)
            //    {
            //        --$scope.canvas_mc._y;
            //    }
            //    else
            //    {
            //        $scope.showSelector();
            //        delete $scope.onEnterFrame;
            //    } // end else if
            //};
        }

        public void onKeyDown()
        {
            //if (Key.isDown(Key.SPACE))
            //{
            //    if (this.canvas_mc._y == 0)
            //    {
            //        this.closeSplash();
            //        Key.removeListener(this);
            //    }
            //    else
            //    {
            //        this.showSelector();
            //    } // end if
            //} // end else if
        }

        public void showSelector()
        {
            //this.bulletTank._visible = true;
            //this.canvas_mc._y = 0;
        }

        public void closeSplash()
        {
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    if ($scope.closerTop._y < -2)
            //    {
            //        $scope.closerTop._y = $scope.closerTop._y + 5;
            //        $scope.closerBottom._y = $scope.closerBottom._y - 5;
            //    }
            //    else
            //    {
            //        $scope.onClose();
            //        delete $scope.onEnterFrame;
            //    } // end else if
            //};
        }

        public void onClose()
        {
            this.broadcastMessage("onClose");
        }

        public void destroy()
        {
            this.removeMovieClip();
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
