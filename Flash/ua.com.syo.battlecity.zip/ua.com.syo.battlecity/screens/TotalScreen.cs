﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens
{
    public class TotalScreen : Flash.Clip
    {
        public TotalScreen()
        {
            //ASSetPropFlags(_loc1, null, 1);
            //this.rows_array = new Array();
            //this.multipleScores_array = new Array(100, 200, 300, 400);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.TotalScreen", ua.com.syo.battlecity.screens.TotalScreen);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.TotalScreen", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.TotalScreen)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.attachMovie("rectangle", "rectangle", this.getNextHighestDepth());
            //this.canvas_mc = this.createEmptyMovieClip("canvas_mc", this.getNextHighestDepth());
            //this.hiScore_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "hiScore_tf", this.canvas_mc.getNextHighestDepth());
            //this.hiScore_num = ua.com.syo.battlecity.components.NESNumField.create(this.canvas_mc, "hiScore_num", this.canvas_mc.getNextHighestDepth());
            //this.stage_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "stage_tf", this.canvas_mc.getNextHighestDepth());
            //this.stage_num = ua.com.syo.battlecity.components.NESNumField.create(this.canvas_mc, "stage_num", this.canvas_mc.getNextHighestDepth());
            //this.firstPlayer_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "firstPlayer_tf", this.canvas_mc.getNextHighestDepth());
            //this.score_num = ua.com.syo.battlecity.components.NESNumField.create(this.canvas_mc, "score_num", this.canvas_mc.getNextHighestDepth());
            //this.total_tf = ua.com.syo.battlecity.components.NESTextField.create(this.canvas_mc, "total_tf", this.canvas_mc.getNextHighestDepth());
            //this.total_num = ua.com.syo.battlecity.components.NESNumField.create(this.canvas_mc, "total_num", this.canvas_mc.getNextHighestDepth());
            //this.whiteLine = this.canvas_mc.attachMovie("rectangle", "whiteLine", this.canvas_mc.getNextHighestDepth());
            //this.closerTop = this.attachMovie("closer", "closerTop", this.getNextHighestDepth());
            //this.closerBottom = this.attachMovie("closer", "closerBottom", this.getNextHighestDepth());
            //this.closerTop._y = -121;
            //this.closerBottom._y = 233;
        }

        public void init()
        {
            //this.scores_array = scores;
            //this.rows_array = new Array();
            //this.currenrRowForShow = 0;
            //this.sum = 0;
            //this.pointSum = 0;
            //this.scoresIncr_array = new Array(0, 0, 0, 0);
            //var _loc4 = 0;
            
            //while (++_loc4, _loc4 < this.scores_array.length)
            //{
            //    this.sum = this.sum + this.scores_array[_loc4];
            //    this.pointSum = this.pointSum + this.scores_array[_loc4] * this.multipleScores_array[_loc4];
            //} // end while
            //AsBroadcaster.initialize(this);
            //this.hiScore_tf.init(65, 16, ua.com.syo.battlecity.data.DataLabels.TOTAL_HI_SCORE, 14166016);
            //this.hiScore_num.init(153, 16, 8, "left", 16554040);
            //this.hiScore_num.setValue("20000");
            //this.stage_tf.init(97, 32, ua.com.syo.battlecity.data.DataLabels.STAGE, 16777215);
            //this.stage_num.init(153, 32, 3, "left", 16777215);
            //this.stage_num.setValue(ua.com.syo.battlecity.data.GlobalStorage.currentStage.toString());
            //this.firstPlayer_tf.init(25, 48, ua.com.syo.battlecity.data.DataLabels.TOTAL_FIRST_PLAYER, 14166016);
            //this.score_num.init(25, 64, 8, "right", 16554040);
            //this.score_num.setValue(ua.com.syo.battlecity.data.GlobalStorage.score.toString());
            //this.total_tf.init(49, 176, ua.com.syo.battlecity.data.DataLabels.TOTAL_TOTAL, 16777215);
            //this.total_num.init(97, 176, 2, "right", 16777215);
            //this.whiteLine._width = 64;
            //this.whiteLine._height = 2;
            //this.whiteLine._x = 96;
            //this.whiteLine._y = 173;
            //var _loc5 = new Color(this.whiteLine);
            //_loc5.setRGB(16777215);
            //var _loc6 = 0;
            
            //while (++_loc6, _loc6 < 4)
            //{
            //    this.createTotalRow(_loc6 + 1);
            //} // end while
            //this.showTotalEnable();
            //if (isGO)
            //{
            //    var _loc7 = new Color(this.closerTop);
            //    _loc7.setRGB(0);
            //    var _loc8 = new Color(this.closerBottom);
            //    _loc8.setRGB(0);
            //} // end if
        }

        public void createTotalRow()
        {
            //var _loc3 = this.canvas_mc.createEmptyMovieClip("row" + rowIndex, this.canvas_mc.getNextHighestDepth());
            //var _loc4 = ua.com.syo.battlecity.components.NESNumField.create(_loc3, "score_num", _loc3.getNextHighestDepth());
            //var _loc5 = ua.com.syo.battlecity.components.NESTextField.create(_loc3, "pts_tf", _loc3.getNextHighestDepth());
            //var _loc6 = ua.com.syo.battlecity.components.NESNumField.create(_loc3, "kill_num", _loc3.getNextHighestDepth());
            //_loc4.init(0, 0, 4, "right", 16777215);
            //_loc4._visible = false;
            //_loc5.init(40, 0, ua.com.syo.battlecity.data.DataLabels.TOTAL_PTS, 16777215);
            //_loc6.init(72, 0, 2, "right", 16777215);
            //_loc6._visible = false;
            //_loc3.attachMovie("<", "<", _loc3.getNextHighestDepth(), {_x: 88, _y: 0});
            //_loc3.attachMovie("totalTank" + rowIndex, "tank" + rowIndex, _loc3.getNextHighestDepth(), {_x: 97, _y: -3});
            //_loc3._x = 25;
            //_loc3._y = 88 + 24 * (rowIndex - 1);
            //this.rows_array.push(_loc3);
        }

        public void setRowData()
        {
            //(ua.com.syo.battlecity.components.NESNumField)((MovieClip)(this.rows_array[rowIndex]).kill_num)._visible = true;
            //(ua.com.syo.battlecity.components.NESNumField)((MovieClip)(this.rows_array[rowIndex]).kill_num).setValue(num.toString());
            //(ua.com.syo.battlecity.components.NESNumField)((MovieClip)(this.rows_array[rowIndex]).score_num)._visible = true;
            //(ua.com.syo.battlecity.components.NESNumField)((MovieClip)(this.rows_array[rowIndex]).score_num).setValue((num * multiplier).toString());
        }

        public void showTotalEnable()
        {
            //if (this.showTotalIntervalId != null)
            //{
            //    _global.clearInterval(this.showTotalIntervalId);
            //} // end if
            //this.showTotalIntervalId = _global.setInterval(this, "showRows", ua.com.syo.battlecity.data.GlobalStorage.totalShowDelay);
        }

        public void showRows()
        {
            //var _loc2 = this.scores_array[this.currenrRowForShow];
            //var _loc3 = 0;
            //if (_loc2 > -1)
            //{
            //    --this.scores_array[this.currenrRowForShow];
            //    _loc3 = this.scoresIncr_array[this.currenrRowForShow]++;
            //    if (_loc3 > 0 || this.currenrRowForShow == 0 && this.scores_array[this.currenrRowForShow] < 0)
            //    {
            //        this.setRowData(this.currenrRowForShow, _loc3, this.multipleScores_array[this.currenrRowForShow]);
            //    } // end if
            //}
            //else
            //{
            //    ++this.currenrRowForShow;
            //    if (this.scores_array[this.currenrRowForShow] == 0)
            //    {
            //        this.setRowData(this.currenrRowForShow, 0, this.multipleScores_array[this.currenrRowForShow]);
            //    } // end if
            //    if (this.currenrRowForShow > 4)
            //    {
            //        Key.addListener(this);
            //        this.runDelay();
            //        _global.clearInterval(this.showTotalIntervalId);
            //        this.total_num.setValue(this.sum.toString());
            //    } // end if
            //} // end else if
        }

        public void onKeyDown()
        {
        }

        public void runDelay()
        {
            //var delay = 100;
            //var $scope = this;
            //this.onEnterFrame = function ()
            //{
            //    --delay;
            //    if (delay < 0)
            //    {
            //        $scope.closeTotal();
            //        delete $scope.onEnterFrame;
            //    } // end if
            //};
        }

        public void closeTotal()
        {
            //var $scope = this;
            //this.canvas_mc.onEnterFrame = function ()
            //{
            //    if ($scope.closerTop._y < -2)
            //    {
            //        $scope.closerTop._y = $scope.closerTop._y + 5;
            //        $scope.closerBottom._y = $scope.closerBottom._y - 5;
            //    }
            //    else
            //    {
            //        $scope.onClose();
            //        delete $scope.canvas_mc.onEnterFrame;
            //    } // end else if
            //};
        }

        public void onClose()
        {
            //Key.addListener(this);
            //this.broadcastMessage("onCloseTotalScreen");
        }

        public void destroy()
        {
            this.removeMovieClip();
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
