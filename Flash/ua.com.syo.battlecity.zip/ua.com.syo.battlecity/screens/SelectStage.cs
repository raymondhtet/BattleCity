﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.screens
{
    public class SelectStage : Flash.Clip
    {
        public SelectStage()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void create(Flash.Clip clip, Flash.var name, Flash.var depth, Flash.Object initObject)
        {
            //Object.registerClass("__Packages.ua.com.syo.battlecity.screens.SelectStage", ua.com.syo.battlecity.screens.SelectStage);
            //var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.screens.SelectStage", name, depth, initObject);
            //var _loc7 = (ua.com.syo.battlecity.screens.SelectStage)(_loc6);
            //_loc7.buildInstance();
            //return (_loc7);
        }

        public void buildInstance()
        {
            //this.label_tf = ua.com.syo.battlecity.components.NESTextField.create(this, "label_tf", this.getNextHighestDepth());
            //this.stage_nf = ua.com.syo.battlecity.components.NESNumField.create(this, "stage_nf", this.getNextHighestDepth());
            //this.load_tf = ua.com.syo.battlecity.components.NESTextField.create(this, "load_tf", this.getNextHighestDepth());
        }

        public void init()
        {
            //this.currentStage = stage;
            //AsBroadcaster.initialize(this);
            //this.label_tf.init(96, 104, ua.com.syo.battlecity.data.DataLabels.STAGE, 0);
            //this.stage_nf.init(143, 104, 3, "left", 0);
            //this.stage_nf.setValue(this.currentStage.toString());
            //Key.addListener(this);
        }

        public void onKeyDown()
        {
            //if (Key.isDown(Key.UP))
            //{
            //    ++this.currentStage;
            //    if (this.currentStage > ua.com.syo.battlecity.data.GlobalStorage.stagesNum)
            //    {
            //        this.currentStage = 1;
            //    } // end if
            //    this.setStage(this.currentStage);
            //} // end if
            //if (Key.isDown(Key.DOWN))
            //{
            //    --this.currentStage;
            //    if (this.currentStage < 1)
            //    {
            //        this.currentStage = ua.com.syo.battlecity.data.GlobalStorage.stagesNum;
            //    } // end if
            //    this.setStage(this.currentStage);
            //} // end if
            //if (Key.isDown(Key.SPACE))
            //{
            //    Key.removeListener(this);
            //    this.broadcastMessage("onSelectStage", this.currentStage);
            //} // end if
        }

        public void destroy()
        {
            this.removeMovieClip();
        }

        public void setStage()
        {
            //this.stage_nf.setValue(stage.toString());
        }

        public void showLoader()
        {
            //this.label_tf._visible = false;
            //this.stage_nf._visible = false;
            //this.load_tf.init(80, 104, ua.com.syo.battlecity.data.DataLabels.LOAD_STAGE, 0);
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
