﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity
{
    public class Main : Flash.Clip
    {
        public Main()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public void main()
        {
            //ua.com.syo.battlecity.Main.preloader = ua.com.syo.battlecity.screens.Preloader.create(_root, "preloader", _root.getNextHighestDepth());
            //ua.com.syo.battlecity.Main.preloader.init();
            //_root.onEnterFrame = function ()
            //{
            //    ua.com.syo.battlecity.Main.preloader.update(_root.getBytesLoaded(), _root.getBytesTotal());
            //    if (_root.getBytesLoaded() == _root.getBytesTotal())
            //    {
            //        delete _root.onEnterFrame;
            //        ua.com.syo.battlecity.Main.initApp();
            //    } // end if
            //};
        }

        public void initApp()
        {
            //var _loc2 = new Date();
            //if (_loc2.getFullYear() < 2008)
            //{
            //    ua.com.syo.battlecity.Main.preloader.remove();
            //    ua.com.syo.battlecity.view.UIManager.create(_root, "uiManager", _root.getNextHighestDepth());
            //    ua.com.syo.battlecity.controller.Controller.getInstance();
            //    ua.com.syo.battlecity.model.Model.getInstance();
            //    ua.com.syo.battlecity.view.UIManager.getInstance().init();
            //    ua.com.syo.battlecity.model.Model.getInstance().init();
            //    ua.com.syo.battlecity.controller.Controller.getInstance().init();
            //    ua.com.syo.battlecity.controller.Controller.getInstance().run();
            //} // end if
        }
    }
}
