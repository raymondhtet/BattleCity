﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.data
{
    public class DataLabels : Flash.var
    {
        public const string PRELOADER_TITLE = "battle city";
        public const string PRELOADER_STATUS = "loading";
        public const string SPLASH_ONE_PL = "|-    00";
        public const string SPLASH_ONE_PL_HI = "hi-";
        public const string SPLASH_ONE_PLAYER = "1 player";
        public const string SPLASH_TWO_PLAYER = "2 players";
        public const string SPLASH_CONSTRUCTION = "construction";
        public const string SPLASH_NAMCO_COPYRIGHT = "© 1980 2007 namco ltd.";
        public const string SPLASH_ALL_RIGHT = "all rights reserved";
        public const string SPLASH_SYO_COPYRIGHT = "2007     syo.com.ua";
        public const string SPLASH_VERSION = "1.0 beta";
        public const string TOTAL_HI_SCORE = "hi-score";
        public const string TOTAL_FIRST_PLAYER = "|-player";
        public const string TOTAL_TOTAL = "total";
        public const string TOTAL_PTS = "pts";
        public const string STAGE = "stage";
        public const string LOAD_STAGE = "load stage ...";

        public DataLabels()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }
    }
}
