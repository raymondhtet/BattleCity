﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.data
{
    public class GlobalStorage : Flash.var
    {
        public static int currentStage = 1;
        public static int lifesNum = 3;
        public static int score = 0;
        public static int currentTankType = 0;

        public const int stagesNum = 35;
        public const string pathToStages = "stages/";
        public const int tanksMoveInterval = 12;
        public const int bombsMoveInterval = 8;
        public const int slidingDelay = 50;
        public const int armorDelay = 1000;
        public const int totalShowDelay = 250;
        public const int enemyStoppedDelay = 500;
        public const int blockStuffDelay = 500;
        public const int delayAfterStage = 100;
        public const int showEnemyInterval = 2000;
        public const int enemyShootDelay = 70;
        public const int maxEnemyOnStage = 4;
        public const int enemychangeDirectionDelay = 50;

        public GlobalStorage()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public static void initDynamicVars()
        {
            currentStage = 1;
            lifesNum = 3;
            score = 0;
            currentTankType = 0;
        }
    }
}
