﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.model
{
    public class HTTPServer : Flash.var
    {
        public HTTPServer()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public void loadXML(Flash.var path, Flash.var stage)
        {
            // this.onStageLoad(ua.com.syo.battlecity.data.StagesMock["stage" + stage]);
        }

        public void onStageLoad(Flash.XML xml)
        {
            this.broadcastMessage("onStageLoad", xml);
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
