﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.model
{
    public class Model : Flash.var
    {
        private ua.com.syo.battlecity.model.HTTPServer server = null;
        public static ua.com.syo.battlecity.model.Model instance = null;

        public Model()
        {
            //ASSetPropFlags(_loc1, null, 1);
        }

        public static ua.com.syo.battlecity.model.Model getInstance()
        {
            if (ua.com.syo.battlecity.model.Model.instance == null)
            {
                ua.com.syo.battlecity.model.Model.instance = new ua.com.syo.battlecity.model.Model();
            } // end if
            return (ua.com.syo.battlecity.model.Model.instance);
        }

        public void init()
        {
            this.server = new ua.com.syo.battlecity.model.HTTPServer();
            this.server.addListener(this);
        }

        public void getMap(Flash.var stage)
        {
            this.server.loadXML(ua.com.syo.battlecity.data.GlobalStorage.pathToStages + "stage" + stage + ".xml", stage);
        }

        public void onStageLoad(Flash.XML xml)
        {
            //ua.com.syo.battlecity.screens.stage.CurrentStageData.fillMap(xml);
            this.broadcastMessage("onStageLoad");
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }
    }
}
