﻿using System;
using System.Collections.Generic;
using System.Text;

namespace flash
{
    public class Flash
    {
        public Flash()
        {
        }

        public static Flash.var Number(Flash.var value)
        {
            return new var();
        }

        public class var
        {
            public var()
            {
            }

            public var(object value)
            {
            }

            public void super()
            {
            }

            public Flash.var slice(Flash.var value1, Flash.var value2)
            {
                return new Flash.var();
            }

            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }

            public Flash.var this[string name]
            {
                get { return new Flash.var(); }
            }

            public Flash.var this[int index]
            {
                get { return new Flash.var(); }
            }

            public Flash.var length
            {
                get { return new var(); }
            }

            public void ForEach(Action<Flash.var> action)
            {
            }

            #region type convertion operators
            public static implicit operator var(bool value)
            {
                return new var();
            }

            public static implicit operator var(byte value)
            {
                return new var();
            }

            public static implicit operator var(char value)
            {
                return new var();
            }

            public static implicit operator var(decimal value)
            {
                return new var();
            }

            public static implicit operator var(double value)
            {
                return new var();
            }

            public static implicit operator var(short value)
            {
                return new var();
            }

            public static implicit operator var(int value)
            {
                return new var();
            }

            public static implicit operator var(long value)
            {
                return new var();
            }

            public static implicit operator var(float value)
            {
                return new var();
            }

            public static implicit operator var(string value)
            {
                return new var();
            }

            public static implicit operator var(byte[] value)
            {
                return new var();
            }

            public static implicit operator var(Guid value)
            {
                return new var();
            }

            public static implicit operator var(DateTime value)
            {
                return new var();
            }

            public static implicit operator var(TimeSpan value)
            {
                return new var();
            }

            public static explicit operator bool(var value)
            {
                return false;
            }

            public static explicit operator byte(var value)
            {
                return 0;
            }

            public static explicit operator char(var value)
            {
                return (char)0;
            }

            public static explicit operator decimal(var value)
            {
                return 0;
            }

            public static explicit operator double(var value)
            {
                return 0;
            }

            public static explicit operator short(var value)
            {
                return 0;
            }

            public static explicit operator int(var value)
            {
                return 0;
            }

            public static explicit operator long(var value)
            {
                return 0L;
            }

            public static explicit operator float(var value)
            {
                return 0.0F;
            }

            public static explicit operator string(var value)
            {
                return "";
            }

            public static explicit operator byte[](var value)
            {
                return null;
            }

            public static explicit operator Guid(var value)
            {
                return new Guid();
            }

            public static explicit operator DateTime(var value)
            {
                return new DateTime();
            }

            public static explicit operator TimeSpan(var value)
            {
                return new TimeSpan();
            }
            #endregion

            #region unary operators
            public static var operator +(var value1)
            {
                return new var();
            }

            public static var operator -(var value1)
            {
                return new var();
            }

            public static var operator !(var value1)
            {
                return new var();
            }

            public static var operator ~(var value1)
            {
                return new var();
            }

            public static var operator ++(var value1)
            {
                return new var();
            }

            public static var operator --(var value1)
            {
                return new var();
            }

            public static bool operator true(var value1)
            {
                return true;
            }

            public static bool operator false(var value1)
            {
                return false;
            }
            #endregion

            #region binary operators
            public static var operator +(var value1, var value2)
            {
                return new var();
            }

            public static var operator -(var value1, var value2)
            {
                return new var();
            }

            public static var operator *(var value1, var value2)
            {
                return new var();
            }

            public static var operator /(var value1, var value2)
            {
                return new var();
            }

            public static var operator %(var value1, var value2)
            {
                return new var();
            }

            public static var operator &(var value1, var value2)
            {
                return new var();
            }

            public static var operator |(var value1, var value2)
            {
                return new var();
            }

            public static var operator ^(var value1, var value2)
            {
                return new var();
            }

            public static var operator <<(var value1, int value2)
            {
                return new var();
            }

            public static var operator >>(var value1, int value2)
            {
                return new var();
            }
            #endregion

            #region comparison operators 
            public static bool operator ==(var value1, var value2)
            {
                return !value1.Equals(value2);
            }

            public static bool operator !=(var value1, var value2)
            {
                return value1.Equals(value2);
            }

            public static var operator <(var value1, var value2)
            {
                return new var();
            }

            public static var operator >(var value1, var value2)
            {
                return new var();
            }

            public static var operator <=(var value1, var value2)
            {
                return new var();
            }

            public static var operator >=(var value1, var value2)
            {
                return new var();
            }
            #endregion
        }

        public class Object
        {
            public Object()
            {
            }

            public static void registerClass(string path, System.Type obj)
            {
            }
        }

        public class Clip : Flash.var
        {
            public Clip()
            {
            }

            public Clip(Flash.var name, Flash.var depth)
            {
            }

            public Flash.Clip attachMovie(Flash.var path, Flash.var name, Flash.var depth)
            {
                return new Flash.Clip();
            }

            public Flash.Clip attachMovie(Flash.var path, Flash.var name, Flash.var depth, Flash.Object initObject)
            {
                return new Flash.Clip();
            }

            public Flash.Clip createEmptyMovieClip(Flash.var name, Flash.var depth)
            {
                return new Clip(name, depth);
            }

            public void removeMovieClip(Flash.Clip value)
            {
            }

            public void removeMovieClip()
            {
            }

            public void gotoAndStop(Flash.var value)
            {
            }

            public Flash.var getNextHighestDepth()
            {
                return 0;
            }

            public Flash.var _visible
            {
                get { return false; }
                set {  }
            }

            public Flash.var _x
            {
                get { return 0; }
                set { }
            }

            public Flash.var _y
            {
                get { return 0; }
                set { }
            }

            public Flash.var _currentframe
            {
                get { return 0; }
                set { }
            }
        }

        public class XML : Flash.var
        {
            public XML(string xml)
            {
            }
        }

        public class XML<T> : Flash.var
        {
            public XML(string xml)
            {
            }
        }

        public class Color : Flash.var
        {
            public Color()
            {
            }

            public Color(Flash.var value)
            {
            }

            public void setRGB(Flash.Color rgb)
            {
            }
        }

    }
}
