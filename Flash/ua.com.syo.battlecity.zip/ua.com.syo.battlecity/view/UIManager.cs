﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.view
{
    public class UIManager : Flash.Clip
    {
        private static UIManager instance = null;

        public UIManager()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }

        public void create()
        {
            //if (ua.com.syo.battlecity.view.UIManager.instance == undefined)
            //{
            //    Object.registerClass("__Packages.ua.com.syo.battlecity.view.UIManager", ua.com.syo.battlecity.view.UIManager);
            //    var _loc6 = clip.attachMovie("__Packages.ua.com.syo.battlecity.view.UIManager", name, depth, initObject);
            //    ua.com.syo.battlecity.view.UIManager.instance = (ua.com.syo.battlecity.view.UIManager)(_loc6);
            //    ua.com.syo.battlecity.view.UIManager.instance.buildInstance();
            //    return (ua.com.syo.battlecity.view.UIManager.instance);
            //}
            //else
            //{
            //    return (ua.com.syo.battlecity.view.UIManager.instance);
            //} // end else if
        }

        public UIManager getInstance()
        {
            if (ua.com.syo.battlecity.view.UIManager.instance == null)
            {
                ua.com.syo.battlecity.view.UIManager.instance = new ua.com.syo.battlecity.view.UIManager();
            } // end if
            return (ua.com.syo.battlecity.view.UIManager.instance);
        }

        public void buildInstance()
        {
        }

        public void init()
        {
            //AsBroadcaster.initialize(this);
        }

        public void showSplashMenu()
        {
            //this.splashMenu = ua.com.syo.battlecity.screens.SplashMenu.create(this, "splashMenu", this.getNextHighestDepth());
            //this.splashMenu.init();
            //this.splashMenu.addListener(this);
        }

        public void showSelectStage()
        {
            //this.splashMenu.destroy();
            //this.selectStage = ua.com.syo.battlecity.screens.SelectStage.create(this, "selectStage", this.getNextHighestDepth());
            //this.selectStage.init(stage);
            //this.selectStage.addListener(this);
        }

        public void showStage()
        {
            //this.selectStage.destroy();
            //this.stage = ua.com.syo.battlecity.screens.stage.Stage.create(this, "stage", this.getNextHighestDepth());
            //this.stage.init();
            //this.stage.addListener(this);
        }

        public void showGameOverScreen()
        {
            //this.goScreen = ua.com.syo.battlecity.screens.GameOverScreen.create(this, "goScreen", this.getNextHighestDepth());
            //this.goScreen.init();
            //this.goScreen.addListener(this);
        }

        public void getStageInstance()
        {
            //return (this.stage);
        }

        public void onClose()
        {
            //this.broadcastMessage("onCloseSplashMenu");
            //this.splashMenu.removeListener(this);
        }

        public void onSelectStage()
        {
            //this.broadcastMessage("onSelectStage", stage);
            //this.selectStage.showLoader();
        }

        public void onStageComplete()
        {
            //this.isGameOver = false;
            //this.total = ua.com.syo.battlecity.screens.TotalScreen.create(this, "total", this.getNextHighestDepth());
            //this.stage.destroy();
            //this.total.init(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array, false);
            //this.total.addListener(this);
        }

        public void onGameOver()
        {
            //this.isGameOver = true;
            //this.total = ua.com.syo.battlecity.screens.TotalScreen.create(this, "total", this.getNextHighestDepth());
            //this.stage.destroy();
            //this.total.init(ua.com.syo.battlecity.screens.stage.CurrentStageData.enemyKill_array, true);
            //this.total.addListener(this);
        }

        public void onCloseTotalScreen()
        {
            //this.total.destroy();
            //this.broadcastMessage("onCloseTotalScreen", this.isGameOver);
        }

        public void onCloseGameOverScreen()
        {
            //this.goScreen.destroy();
            //this.broadcastMessage("onTheEnd");
        }

        public void broadcastMessage(Flash.var eventName, params Flash.var[] par)
        {
        }

        public Flash.var addListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var removeListener(Flash.var listenerObj)
        {
            return null;
        }

        public Flash.var className
        {
            get { return "__Prototype.ua.com.syo.battlecity.view.UIManager"; }
        }

        public Type classFunction
        {
            get { return typeof(ua.com.syo.battlecity.view.UIManager); }
        }
    }
}
