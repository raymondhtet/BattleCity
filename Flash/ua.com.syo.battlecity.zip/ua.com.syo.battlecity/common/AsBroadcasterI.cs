﻿using System;
using System.Collections.Generic;
using System.Text;

using flash;

namespace ua.com.syo.battlecity.common
{
    public class AsBroadcasterI : Flash.var
    {
        public AsBroadcasterI()
        {
            // ASSetPropFlags(_loc1, null, 1);
        }
    }
}
